#  Ths file replicates the ONLINE APPENDIX of: 
#  López-Cariboni & Cao (2015), "Import Competition and Policy Diffusion", Politics & Society, 43(4): 471­-502.


# functions, packages, and data
rm(list=ls())
setwd ("../ReplicationMaterials")
library(plm)
library(foreign)
data <- read.csv("ICPDdata.csv")

#------------ Table A1 ------------#
# Model 1
ssw2a <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(importsgdp, 1)
		+ lag(exportsgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2a <- plm(ssw2a,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2a)
###### LRM
ssw2alrm <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(importsgdp, 1)
		+ lag(exportsgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw2alrm <- plm(ssw2alrm,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2alrm)

# Model 2
ssw2b <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(importsgdp, 1)
		+ Dimportsgdp
		+ lag(exportsgdp, 1)
		+ Dexportsgdp		
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2b <- plm(ssw2b,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2b)
# LRM
ssw2blrm <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(importsgdp, 1)
		+ Dimportsgdp
		+ lag(exportsgdp, 1)
		+ Dexportsgdp		
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw2blrm <- plm(ssw2blrm,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2blrm)

# Model 3
ehh2a <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(importsgdp, 1)
		+ lag(exportsgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh2a <- plm(ehh2a,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh2a)
# LRM
ehh2alrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc) 
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(importsgdp, 1)
		+ lag(exportsgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh2alrm <- plm(ehh2alrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh2alrm)

# Model 4
ehh2b <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(importsgdp, 1)
		+ Dimportsgdp
		+ lag(exportsgdp, 1)
		+ Dexportsgdp		
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh2b <- plm(ehh2b,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh2b)
# LRM
ehh2blrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc) 
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(importsgdp, 1)
		+ Dimportsgdp
		+ lag(exportsgdp, 1)
		+ Dexportsgdp		
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh2blrm <- plm(ehh2blrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh2blrm)


#------------ Table A1 ------------#
# Table A2. Robustness Checks: Left Government and Deindustrialization.

# Model 1 : Social Insurance 
ssw2LeftIndusR <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(deindustrigdp, 1)
		+ lag(left)
		))
mssw2LeftIndusR <- plm(ssw2LeftIndusR,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2LeftIndusR)
# LRM
ssw2lrmRplp <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(deindustrigdp, 1)
		+ lag(left)
		| . - Dsswgdp + Lsswgdp
		))
mssw2lrmRplp <- plm(ssw2lrmRplp,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2lrmRplp)

# Model 2 : Progressive Spending 
ehh0LeftIndusR <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(deindustrigdp, 1)
		+ lag(left)
		))
mehh0LeftIndusR <- plm(ehh0LeftIndusR,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0LeftIndusR)
# LRM
ehh0LeftIndusRlrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(deindustrigdp, 1)
		+ lag(left)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh0LeftIndusRlrm <- plm(ehh0LeftIndusRlrm,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0LeftIndusRlrm)



#------------ Table A3 ------------#
# Table A3. Robustness Checks: Policy Interdependence Conditional to Left Government

# Model 1 : Social Insurance
ssw2plpR <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(left)
		+ I(lag(w.sswgdp)*lag(left))
		))
mssw2plpR <- plm(ssw2plpR,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2plpR)
# LRM
ssw2lrmRplp <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(left)
		+ I(lag(w.sswgdp)*lag(left))
		| . - Dsswgdp + Lsswgdp
		))
mssw2lrmRplp <- plm(ssw2lrmRplp,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2lrmRplp)
# Model 2 : Progressive Spending 
ehh0plpR <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(left)
		+ I(lag(w.social_spending_gdp_perc)*lag(left))
		))
mehh0plpR <- plm(ehh0plpR,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0plpR)
# LRM
ehh0plpRlrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		+ lag(left)
		+ I(lag(w.social_spending_gdp_perc)*lag(left))
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh0plpRlrm <- plm(ehh0plpRlrm,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0plpRlrm)




#------------ Table A4 ------------#
# Table A4. Robustness Checks: Interdependence in Social Insurance using Weighted Structural Equivalences and Spatial Lags of Import Penetration Flows.

# Model 1
ssw2WR1 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.se.imports.ij.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR1 <- plm(ssw2WR1,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR1)

# Model 2
ssw2WR2 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.se.imp.ij.ii.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR2 <- plm(ssw2WR2,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR2)

# Model 3
ssw2WR3 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.se.w.imp.ij.ii.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR3 <- plm(ssw2WR3,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR3)


# Model 4
ssw2WR4 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(imports.ij.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR4 <- plm(ssw2WR4,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR4)

# Model 5
ssw2WR5 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(imp.ij.ii.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR5 <- plm(ssw2WR5,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR5)

# Model 6
ssw2WR6 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.imp.ij.ii.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2WR6 <- plm(ssw2WR6,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2WR6)



#------------ Table A5 ------------#
# Table A5. Robustness checks: Interdependence in Progressive Social Spending using Weighted Structural Equivalences and Spatial Lags of Import Penetration Flows.

# Model 1
ehh02WR1 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(w.se.imports.ij.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR1 <- plm(ehh02WR1,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR1)

# Model 2
ehh02WR2 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(w.se.imp.ij.ii.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR2 <- plm(ehh02WR2,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR2)

# Model 3
ehh02WR3 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(w.se.w.imp.ij.ii.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR3 <- plm(ehh02WR3,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR3)

# Model 4
ehh02WR4 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(imports.ij.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR4 <- plm(ehh02WR4,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR4)

# Model 5
ehh02WR5 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(imp.ij.ii.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR5 <- plm(ehh02WR5,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR5)


# Model 6
ehh02WR6 <- dynformula(as.formula(social_spending_gdp_perc ~ Lsocial_spending_gdp_perc
		+ lag(w.imp.ij.ii.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh02WR6 <- plm(ehh02WR6,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh02WR6)


#------------ end of file ------------#
