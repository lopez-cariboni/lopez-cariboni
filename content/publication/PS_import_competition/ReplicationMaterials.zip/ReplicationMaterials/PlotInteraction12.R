# PlotInteraction, Version: 1.2
# July 2014
# Santiago Lopez Cariboni
# Description: This function plots interaction effects for continuous variables. 
# 			   It allows to declare that the log of Z modifying variable was used in the estimation model (so it takes the exp()), 
#              or that the log of the X axis should be displayed for easy of presentation (so it takes the log() ex-post).


plot.interaction <- function(X, Z, XZ, model.name, 
							Xaxis.log=FALSE, 
							Z.log=FALSE, Zorigin=FALSE,
							Z.hist=FALSE,
							Xvar.name=FALSE,
							Zvar.name=FALSE,
							ylim=c(FALSE,FALSE),
							xlim=c(FALSE,FALSE)) {
	model <- model.name
	# betas <- names(coefficients(model))
	v1  <- X
	v2  <- Z
	v1v2  <- XZ

	b1 <- coefficients(model)[v1]
	b2 <- coefficients(model)[v2]
	b3 <- coefficients(model)[v1v2]

	varb1  <- vcov(model)[v1, v1]
	varb2  <- vcov(model)[v2, v2]
	varb3  <- vcov(model)[v1v2, v1v2]
	covb1b3 <- vcov(model)[v1, v1v2]

	Z.var <- as.numeric(model$model[,names(b2)])
	min <- summary(Z.var)[c("Min.")]
	max <- summary(Z.var)[c("Max.")]
	# min <- quantile(Z.var, probs = 0.1/100, na.rm=TRUE)
	# max <- quantile(Z.var, probs = 99.9/100, na.rm=TRUE)
	mod.z <- seq(min, max, length.out=length(Z.var))
	mar.eff.b1 <- b1+b3*mod.z
	se.mef.b1 <- sqrt(varb1+varb3*(mod.z^2)+2*covb1b3*mod.z) 
	ci.upper <-  mar.eff.b1 + 1.96*se.mef.b1
	ci.lower <-  mar.eff.b1 - 1.96*se.mef.b1

	par(mfrow=c(1, 1), mar=c(3,3,2,2), mgp=c(2,.5,0), las=1, oma=c(0, 0, 0, 0), 
		cex.axis=1, cex.lab=1)
	# pdf("int.pdf", width=6, height=6)

	Z.var.log <- ifelse(rep(min(Z.var)<1,length(Z.var)), abs(min(Z.var))+1 + Z.var, Z.var)
	Z.var.log <- ifelse(Z.var.log==Z.var, Z.var, log(Z.var.log)-log(abs(min(Z.var)+1)))

	ylim.auto <-  c(min(ci.lower)-sqrt(var(mar.eff.b1)), max(ci.upper)+sqrt(var(mar.eff.b1)))
	mod.z.logaxis <- ifelse(rep(min(mod.z)<1,length(mod.z)), abs(min(mod.z))+1 + mod.z, mod.z)
	mod.z.logaxis <- ifelse(mod.z.logaxis==mod.z, mod.z, log(mod.z.logaxis)-log(abs(min(mod.z)+1)))

if(Z.hist==TRUE){

	if(Xaxis.log=="TRUE"){
	hist(Z.var.log,	breaks=70,col="grey", border="grey",axes=F, xaxt="n",main="", xlab="", ylab="")
	par(new=TRUE)
		plot(mod.z.logaxis, mar.eff.b1,
			ylim = ifelse(ylim==c(FALSE,FALSE),ylim.auto, ylim),
			xlim = range(mod.z.logaxis),
			axes= FALSE, 
			type="l", lty=1,  col=gray(.4),
			ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
			xlab=ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
			xpd = TRUE)
		lines(mod.z.logaxis, ci.upper, cex=1, lty=2, col="black") 
		lines(mod.z.logaxis, ci.lower, cex=1, lty=2, col="black")
	    axis(1, )
    	axis(2, )}

	else{if(Z.log=="TRUE"){
		hist(exp(Z.var)+min(na.omit(Zorigin)), breaks=70, col="grey", border="grey", axes=F, xaxt="n", main="", xlab="", ylab="")
		par(new=TRUE)
		plot(exp(mod.z)+min(na.omit(Zorigin)), mar.eff.b1, ylim=ifelse(ylim==c(FALSE,FALSE),ylim.auto, ylim),
			# xlim = exp(mod.z)+min(na.omit(Zorigin)),
			axes=FALSE, 
			type="l", lty=1,  col=gray(.4),
			ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
			xlab=ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
			xpd = TRUE)
		lines(exp(mod.z)+min(na.omit(Zorigin)), ci.upper, cex=1, lty=2, col="black")
    	lines(exp(mod.z)+min(na.omit(Zorigin)), ci.lower, cex=1, lty=2, col="black")
    	axis(1, )
    	axis(2, )}

	else{
		hist(Z.var, breaks=70, col="grey", border="grey", axes=F, xaxt="n", main="", xlab="", ylab="")
		par(new=TRUE)
		plot(mod.z, mar.eff.b1, ylim=ifelse(ylim==c(FALSE,FALSE), ylim.auto, ylim),
			xlim = range(mod.z),
	   		axes=FALSE, 
	   		type="l", lty=1,  col=gray(.4),
	   		ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
	   		xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
	    	xpd = TRUE)
			lines(mod.z, ci.upper, cex=1, lty=2, col="black")
			lines(mod.z, ci.lower, cex=1, lty=2, col="black")
		axis(1, )
    	axis(2, )}
	}
}

else{
	if(Xaxis.log=="TRUE"){
	# hist(Z.var.log,	breaks=70,col="grey", border="grey",axes=F, xaxt="n",main="", xlab="", ylab="")
	# par(new=TRUE)
		plot(mod.z.logaxis, mar.eff.b1,
			ylim = ifelse(ylim==c(FALSE,FALSE),ylim.auto, ylim),
			xlim = range(mod.z.logaxis),
			axes= FALSE, 
			type="l", lty=1,  col=gray(.4),
			ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
			xlab=ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
			xpd = TRUE)
		lines(mod.z.logaxis, ci.upper, cex=1, lty=2, col="black") 
		lines(mod.z.logaxis, ci.lower, cex=1, lty=2, col="black")
	    axis(1, )
    	axis(2, )}

	else{if(Z.log=="TRUE"){
		# hist(exp(Z.var)+min(na.omit(Zorigin)), breaks=70, col="grey", border="grey", axes=F, xaxt="n", main="", xlab="", ylab="")
		# par(new=TRUE)
		plot(exp(mod.z)+min(na.omit(Zorigin)), mar.eff.b1, ylim=ifelse(ylim==c(FALSE,FALSE),ylim.auto, ylim),
			# xlim = exp(mod.z)+min(na.omit(Zorigin)),
			axes=FALSE, 
			type="l", lty=1,  col=gray(.4),
			ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
			xlab=ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
			xpd = TRUE)
		lines(exp(mod.z)+min(na.omit(Zorigin)), ci.upper, cex=1, lty=2, col="black")
    	lines(exp(mod.z)+min(na.omit(Zorigin)), ci.lower, cex=1, lty=2, col="black")
    	axis(1, )
    	axis(2, )}

	else{
		# hist(Z.var, breaks=70, col="grey", border="grey", axes=F, xaxt="n", main="", xlab="", ylab="")
		# par(new=TRUE)
		plot(mod.z, mar.eff.b1, ylim=ifelse(ylim==c(FALSE,FALSE), ylim.auto, ylim),
			xlim = range(mod.z),
	   		axes=FALSE, 
	   		type="l", lty=1,  col=gray(.4),
	   		ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, names(b1), Xvar.name), sep=" "),
	   		xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
	    	xpd = TRUE)
			lines(mod.z, ci.upper, cex=1, lty=2, col="black")
			lines(mod.z, ci.lower, cex=1, lty=2, col="black")
		axis(1, )
    	axis(2, )}
	}
}
	abline (0,0,lwd=.5, lty=2)
}
