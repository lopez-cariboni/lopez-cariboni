#  Ths file replicates tables and figures in: 
#  López-Cariboni & Cao (2015), "Import Competition and Policy Diffusion", Politics & Society, 43(4): 471­-502.


# functions, packages, and data
rm(list=ls())
setwd ("../ReplicationMaterials") # adjust to your path!
source("PlotInteraction12.R")
source("lagpanel.r")
library(MASS)
library(plm)
library(arm)
library(foreign)
library(lattice)
library(AER)
data <- read.csv("ICPDdata.csv")

#------------ Table 3 ------------#
# Model 1
ssw0 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw0 <- plm(ssw0,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mssw0)
# LRM
ssw0lrm <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw0lrm <- plm(ssw0lrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw0lrm)


# Model 2
ssw1 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(tradegdp, 1)  
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw1 <- plm(ssw1,
		  effect="twoways",  
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw1)
# LRM
ssw1lrm <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(tradegdp, 1)  
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw1lrm <- plm(ssw1lrm,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw1lrm)

# Model 3
ssw2 <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(polity2, 1)   
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2 <- plm(ssw2,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2)
# LRM
ssw2lrm <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)
		+ lag(wSeExp.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ lag(polity2, 1)   
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw2lrm <- plm(ssw2lrm,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2lrm)


# get the list of countries in sample for the first model.
mssw0 <- plm(ssw0, effect="twoways", data=data, na.action=na.exclude, index = c("isoname","year"))
as.character(names(fixef(mssw0)))


#------------ Table 4 ------------#
# Table 4.  Import Competition and Progressive Spending (Health, Housing, and Education) in LDCs. (page 487)


# Model 1
ehh0 <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh0 <- plm(ehh0,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0)
# LRM
ehh0lrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc) 
		+ lag(w.social_spending_gdp_perc, 1) 
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh0lrm <- plm(ehh0lrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh0lrm)


# Model 2
ehh1 <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(tradegdp, 1)  
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh1 <- plm(ehh1,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh1)
# LRM
ehh1lrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc) 
		+ lag(w.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(tradegdp, 1)  
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh1lrm <- plm(ehh1lrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh1lrm)

# Model 3
ehh2 <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(polity2, 1)   
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh2 <- plm(ehh2,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh2)
# LRM
ehh2lrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc) 
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(wSeExp.social_spending_gdp_perc, 1)
		+ lag(log(1+plp), 1)
		+ lag(polity2, 1)   
		+ lag(log(1+wagecov), 1)
		+ lag(tradegdp, 1)  
		+ lag(isi_positive, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)    
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh2lrm <- plm(ehh2lrm, 
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mehh2lrm)

# get the list of countries in sample for the first model.
mehh0 <- plm(ehh0, effect="twoways", data=data, na.action=na.exclude, index = c("isoname","year"))
as.character(names(fixef(mehh0)))


#------------ Figure 2 ------------#
# Figure 2.  Diffusion Effects in Social Insurance and Progressive Social Spending. (page 488)
# Note: Dots and lines depict LRM and 95 percent confidence intervals for import competition interdependence in social insurance spending (models from Table 3) and progressive social spending (models from Table 4).

t1coef <-  c(mssw0lrm$coefficients[2],mssw1lrm$coefficients[2],mssw2lrm$coefficients[2])
t2coef <-  c(mehh0lrm$coefficients[2],mehh1lrm$coefficients[2],mehh2lrm$coefficients[2])
t1se <-  c(sqrt(diag(mssw0lrm$vcov))[2],sqrt(diag(mssw1lrm$vcov))[2],sqrt(diag(mssw2lrm$vcov))[2])
t2se <-  c(sqrt(diag(mehh0lrm$vcov))[2],sqrt(diag(mehh1lrm$vcov))[2],sqrt(diag(mehh2lrm$vcov))[2])
model.names <- 1:3
ciplot.data <- cbind(t1coef, t2coef, t1se, t2se)

pdf("effects.pdf", width=10, height=6)
plot(ciplot.data[,1],model.names+.1, ylim=range(0.2:3.5), xlim=c(-1,2.5), axes=F, ylab="", xlab="", pch=15, col="black")
points(ciplot.data[,2],1:length(t1coef)-.1, pch=16, col="black")
text(y=model.names, x=-.8, c("model 1", "model 2", "model 3"))
segments(ciplot.data[,1]-ciplot.data[,3]*1.96,1:length(t1coef)+.1, ciplot.data[,1]+ciplot.data[,3]*1.96,1:length(t1coef)+.1)
segments(ciplot.data[,2]-ciplot.data[,4]*1.96,1:length(t1coef)-.1, ciplot.data[,2]+ciplot.data[,4]*1.96,1:length(t1coef)-.1)
axis(1, at=c(seq(-.5,2,.5)))
abline(v=0, col="darkgrey", lty=2)
legend(x=1, y=.5, legend = c("Diffusion of Social Insurance","Diffusion of Progressive Spending"), pch=c(15,16), lty = c(1, 1, 1), col=c("black","black"), bty = "n", cex = .8)
dev.off()



#------------ Table 5 ------------#
# Table 5.  Conditional Imports Competition and Policy Interdependence in LDCs. (page 489)

# Model 1
ssw2plp <- dynformula(as.formula(sswgdp ~ Lsswgdp
		+ lag(w.sswgdp, 1)
		+ lag(log(1+plp), 1)
		+ I(lag(w.sswgdp*log(1+plp), 1))
		+ lag(wSeExp.sswgdp, 1)
		+ lag(tradegdp, 1)
		+ lag(polity2, 1)
		+ lag(isi_positive, 1)
		+ lag(wagecov, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mssw2plp <- plm(ssw2plp,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2plp)
#### LRM
ssw2lrmplp <- dynformula(as.formula(sswgdp ~ Dsswgdp 
		+ lag(w.sswgdp, 1)  
		+ lag(log(1+plp), 1)
		+ I(lag(w.sswgdp*log(1+plp), 1))
		+ lag(wSeExp.sswgdp, 1)
		+ lag(tradegdp, 1)
		+ lag(polity2, 1)
		+ lag(isi_positive, 1)
		+ lag(wagecov, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - Dsswgdp + Lsswgdp
		))
mssw2lrmplp <- plm(ssw2lrmplp,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(mssw2lrmplp)

# Model 2
ehh0plp <- dynformula(as.formula(social_spending_gdp_perc ~ lag(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(log(1+plp), 1)
		+ I(lag(w.social_spending_gdp_perc*log(1+plp), 1))
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(tradegdp, 1)
		+ lag(polity2, 1)
		+ lag(isi_positive, 1)
		+ lag(wagecov, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		))
mehh0plp <- plm(ehh0plp,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0plp)
#### LRM
ehh0plplrm <- dynformula(as.formula(social_spending_gdp_perc ~ diff(social_spending_gdp_perc)
		+ lag(w.social_spending_gdp_perc, 1)  
		+ lag(log(1+plp), 1)
		+ I(lag(w.social_spending_gdp_perc*log(1+plp), 1))	
		+ lag(wSeExp.social_spending_gdp_perc, 1)  
		+ lag(tradegdp, 1)
		+ lag(polity2, 1)
		+ lag(isi_positive, 1)
		+ lag(wagecov, 1)
		+ lag(dependency, 1)
		+ lag(urbpop, 1)
		+ lag(log(pop_total), 1)
		+ lag(log(gdppcconstus), 1)
		+ lag(govgdp, 1)
		| . - diff(social_spending_gdp_perc) + lag(social_spending_gdp_perc)
		))
mehh0plplrm <- plm(ehh0plplrm,
		  effect="twoways",
		  data=data,
		  na.action=na.exclude,
		  index = c("iso3c","year"))
summary(mehh0plplrm)

#------------ Figure 3 ------------#
# Figure 3.  Marginal Long-Run Effects of Diffusion through Import Competition on Social Insurance 
#            Conditional on Potential Labor Power (Logged). (page 490)

pdf("plp.pdf", width=6, height=5)
plot.interaction(model.name=mssw2lrmplp, X="lag(w.sswgdp, 1)", Z="lag(log(1 + plp), 1)", 
	XZ="I(lag(w.sswgdp * log(1 + plp), 1))", Z.hist=TRUE,
	Xvar.name="Diffusion through Import Competition",
	Zvar.name="Potential Labor Power (Log)")
dev.off()


#------------ Table 6 ------------#
# Table 6.  Imports Competition and Social Insurance in LDCs Conditioned by PLP and Interindustry Labor Mobility. (page 491)
# note: manually created lags are used for easy of plotting table 4. 

# Model 1
sswwagecov <- dynformula(as.formula(sswgdp ~ Lsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + Lgdppcconstuslog
            + Lgovgdp
            ))
msswwagecov1 <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov1)
# LRM
sswwagecov <- dynformula(as.formula(sswgdp ~ Dsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + Lgdppcconstuslog
            + Lgovgdp
            | . - Dsswgdp + Lsswgdp
            ))
msswwagecov1lrm <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov1lrm)

# Model 2
sswwagecov <- dynformula(as.formula(sswgdp ~ Lsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + LwSeExp.sswgdp
            + Ltradegdp
            + Lpolity2
            + Ldependency
            + Lurbpop
            + Lpop_totallog
            + Lgdppcconstuslog
            + Lgovgdp
            ))
msswwagecov2 <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov2)
# LRM
sswwagecov <- dynformula(as.formula(sswgdp ~ Dsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + LwSeExp.sswgdp
            + Ltradegdp
            + Lpolity2
            + Ldependency
            + Lurbpop
            + Lpop_totallog
            + Lgdppcconstuslog
            + Lgovgdp 
            | . - Dsswgdp + Lsswgdp
            ))
msswwagecov2lrm <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov2lrm)

# Model 3
sswwagecov <- dynformula(as.formula(sswgdp ~ Lsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + LwSeExp.sswgdp
            + Ltradegdp
            + Lpolity2
            + Ldependency
            + Lurbpop
            + Lpop_totallog
            + Lgdppcconstuslog
            + Lgovgdp
            + Lisi_positive
            ))
msswwagecov3 <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov3)
# LRM
sswwagecov <- dynformula(as.formula(sswgdp ~ Dsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + LwSeExp.sswgdp
            + Ltradegdp
            + Lpolity2
            + Lisi_positive
            + Lurbpop
            + Lpop_totallog
            + Lgdppcconstuslog
            + Lgovgdp
            + Ldependency
            | . - Dsswgdp + Lsswgdp
            ))
msswwagecov3lrm <- plm(sswwagecov,
		  effect="twoways",
		  data=data,
		  na.action=na.omit,
		  index = c("iso3c","year"))
summary(msswwagecov3lrm)



#------------ Figure 4 ------------#
# Figure 4.  Simulated Long-Run Levels of Social Insurance Spending Conditional on 
#            Import Competition Interdependence, Potential Labor Power, and Interindustry Wage Variation. (page 492)


#estimate a model with LRM
mssw2plp <- ivreg(sswgdp ~ 
            + as.factor(year)
            + iso3c
            - 1
            + Dsswgdp
            + Lw.sswgdp
            + Lplplog
            + Lwagecovlog
            + I(Lw.sswgdp*Lplplog)
            + I(Lw.sswgdp*Lwagecovlog)
            + I(Lwagecovlog*Lplplog)
            + I(Lw.sswgdp*Lplplog*Lwagecovlog)
            + LwSeExp.sswgdp
            + Ltradegdp
            + Lpolity2
            + Lisi_positive
            + Ldependency
            + Lurbpop
            + Lpop_totallog
            + Lgdppcconstuslog
            + Lgovgdp 
            | . - Dsswgdp + Lsswgdp,
			data      =data,
			na.action =na.omit)
summary(mssw2plp)
#extract data from the model
model <- mssw2plp$model
#choose the length of the plot grid
n.grid <- 25
# counterfactuals 1: low wage covariance
Lwagecovlog <- with(data, rep(quantile(Lwagecovlog, .1, na.rm=T)[[1]], len=n.grid)) 
Lw.sswgdp   <- with(data, seq(quantile(Lw.sswgdp, .1, na.rm=T), quantile(Lw.sswgdp, .9, na.rm=T), len=n.grid))
Lplplog     <- with(data, seq(quantile(Lplplog, .1, na.rm=T), quantile(Lplplog, .9, na.rm=T), len=n.grid))
simdata   <- expand.grid(Lw.sswgdp, Lplplog)
simdata   <- cbind(simdata, Lwagecovlog)        # cbind counterfactuals
names(simdata) <- c("Lw.sswgdp","Lplplog", "Lwagecovlog")
# Xs' at their means
Xs <- c("Dsswgdp",
        "Lsswgdp", 
        "LwSeExp.sswgdp",
        "Ltradegdp",
        "Lpolity2",
        "Lisi_positive",
        "Ldependency",
        "Lurbpop",
        "Lpop_totallog",
        "Lgdppcconstuslog",
        "Lgovgdp")
for (i in Xs) {
   simdata[,i] <-  rep(mean(model[,i]), nrow(simdata))
}
#Fixed Effects
iso3c <- as.factor(rep("MAR", nrow(simdata)))
year <- as.factor(rep(1990, nrow(simdata)))
#produce simulated data
simdata <- cbind(simdata, iso3c, year)        # cbind fixed effects
# Simluate Y hat for "counterfactuals 1"
fit1 <- predict(mssw2plp, simdata, se.fit = T)
# counterfactuals 2: high wage covariance
simdata$Lwagecovlog <- with(data, rep(quantile(Lwagecovlog, .8, na.rm=T)[[1]], len=n.grid))
# Simluate Y hat for "counterfactuals 2"
fit2 <- predict(mssw2plp, simdata, se.fit = T)
# Now plot...
pdf("ssw_threeway.pdf", width=5, height=5)
trellis.par.set("axis.line", list(col = "transparent")) # removes the box  
wireframe (fit1 + fit2~ exp(simdata$Lplplog) * simdata$Lw.sswgdp,
    # auto.key = T,
    # colorkey = T, 
    light.source= c(5,25,5),
    drape = FALSE,
     shade = T,
    shade.colors = function(irr, ref, height, w = 0.4)
    grey(w * irr + (1 - w) * (1 - (1 - ref)^0.4)),
	aspect = c(1, 1),
    scales = list(arrows = FALSE, cex = .7, col = "black", font = 1),
    screen = list(z = 55, x = -60),
    xlab = list("PLP", rot=46),
    ylab = list("Interdependence", rot=-24),
    zlab = list("Social Security", rot=94))
    grid::grid.text("High mobility", x= 0.9, y=0.7)
    grid::grid.text("Low mobility",  x= 0.89, y=0.57)    
dev.off()


#------------ end of file ------------#
