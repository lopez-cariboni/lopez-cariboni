# Replication code
# López-Cariboni, Santiago. 2019. "Informal Service Access in Pro-cyclical Welfare States: A Comparison of Electricity Theft in Slums and Regular Residential Areas of Montevideo." 
# *Journal of Comparative Policy Analysis: Research and Practice* (21)3: 287-305. 


# ---- packages ----
rm(list=ls())
options(scipen=1) 
library(foreign)
library(texreg)
library(tseries)
library(lmtest)



# ---- Figure 2 ----
rm(list=ls())
setwd("~/Dropbox/Research/Publications/Informal Service Access SPOM - JCPA/ReplicationMaterials/")
context <- read.csv("poverty_slum_population.csv", sep=",", header=TRUE)

pdf('./Figure2.pdf')
plot(context$Year, context$Poverty,
     xlim = c(1998, 2011),
     ylim = c(0, 50),
     ylab="Percentage",  
     xlab="Year", 
     axes = FALSE, 
	 # pch = 19,
	 col="black",
	type="l",
	lty=c(1)
	)
axis(1, at= seq(1998,2011,1))
axis(2, at = pretty(range(0:50)))
lines(context[,"Year"], context[,"Informality"], lty = 2) 
points(context[,"Year"], context[,"Slumpop"], pch=19) 
lines(context[,"Year"], c(na.approx(context[,"Slumpop"]), rep(NA,5)), lty=3) 
legend("topright", legend =c("Population under poverty", "Informality as % of employed", "Population living in slums"), 
lty= c(1:3), pch=c(NA,NA,19), col="black", bty = "n", cex=1)
dev.off()

# ---- Load data ----
rm(list=ls())
setwd("~/Dropbox/Research/Publications/Informal Service Access SPOM - JCPA/ReplicationMaterials/")
data <- read.csv("data_monthly.csv", sep=",", header=TRUE)

names(data)
# "date"                          
# "month"                         
# "year"                          
# "td.loss" - Transmission and distribution losses                       
# "nt.loss.nonpoor" Non-technical losses among the non-poor               
# "nt.loss.poor" Non-technical losses among the poor
# "td.loss.mvdeo" - Transmission and distribution losses (Montevideo)                
# "nt.loss.nonpoor.mvdeo" Non-technical losses among the non-poor (Montevideo)         
# "nt.loss.poor.mvdeo" Non-technical losses among the poor (Montevideo)
# "td.MWh.year"                   
# "td.loss.MWh.year"              
# "nt.loss.MWh.year.nonpoor"      
# "nt.loss.MWh.year.poor"         
# "td.MWh.year.mvdeo"             
# "td.loss.MWh.year.mvdeo"        
# "nt.loss.MWh.year.nonpoor.mvdeo"
# "nt.loss.MWh.year.poor.mvdeo"   
# "source.td.MWh.year"            
# "source.td.MWh.year.mvdeo"      
# "source.td.loss.MWh.year"       
# "source.td.loss.MWh.year.mvdeo" 
# "source.nt.loss.MWh.year.poor"  
# "sold.MWh.year"                 
# "sold.MWh.month"                
# "sold.MWh.year.mvdeo"           
# "sold.MWh.month.mvdeo"          
# "sold.MWh.year.house"           
# "sold.MWh.month.house"          
# "sold.MWh.year.publiclights"    
# "sold.MWh.month.publiclights"   
# "household.clients.total"       
# "unempl.mvdeo.ma" Unemployment in Montevideo (moving average)              
# "unempl.mvdeo" Unemployment in Montevideo                  
# "empl.mvdeo"                    
# "pib.const"                     
# "pib.const.ma"                  
# "l.pib.const.ma"                
# "d.pib.const.ma"                
# "pib.const.ma.index"            
# "l.pib.const.ma.index"          
# "l4.pib.const.ma"               
# "l4.pib.const.ma.index" 

# ---- decomposition_unemp ----
data.ts <- ts(data, frequency=12, start=c(1995,1))
unempl.mvdeo.dc <- decompose(window(data.ts[,'unempl.mvdeo'], start=1999, end=c(2012,1)))
unempl.mvdeo.des <- data.ts[,'unempl.mvdeo']-unempl.mvdeo.dc$seasonal
unempl.mvdeo.trend <- unempl.mvdeo.dc$trend
varnames <- colnames(data.ts)
data.ts <- cbind(data.ts, unempl.mvdeo.des, unempl.mvdeo.trend)
colnames(data.ts) <- c(varnames ,'unempl.mvdeo.des', 'unempl.mvdeo.trend')
data <- as.data.frame(data.ts)

# ---- vars ----
data$time <- 1:dim(data)[1]
# electricity losses
data$ntloss.MWh.mv <- data$nt.loss.MWh.year.poor.mvdeo + data$nt.loss.MWh.year.nonpoor.mvdeo
data$ntloss.MWh <- data$nt.loss.MWh.year.poor + data$nt.loss.MWh.year.nonpoor
data$ntloss.mv <- data$nt.loss.nonpoor.mvdeo + data$nt.loss.poor.mvdeo
data$ntloss.pnp <- data$nt.loss.poor / data$nt.loss.nonpoor
data$ntloss.pnp.mv <- data$nt.loss.poor.mvdeo / data$nt.loss.nonpoor.mvdeo
data$ntloss <- data$nt.loss.nonpoor + data$nt.loss.poor
data$time.trend <- seq(1: dim(data)[1])

#election time
data$election <- rep(0, dim(data)[1])
data$election <- ifelse(data[,3]==1999 & data[,4]<=9 ,1,data$election)
data$election <- ifelse(data[,3]==2004 & data[,4]<=9 ,1,data$election)
data$election <- ifelse(data[,3]==2009 & data[,4]<=9 ,1,data$election)
data$election <- ifelse(data[,3]==2014 & data[,4]<=9 ,1,data$election)

data$left1 <- rep(0, dim(data)[1])
data$left1 <- ifelse(data[,3]==2005 & data[,4]>=4 ,1,data$left1)
data$left1 <- ifelse(data[,3]>=2006 & data[,3]<=2009,1,data$left1)
data$left1 <- ifelse(data[,3]==2010 & data[,4]<=3 ,1,data$left1)

data$left2 <- rep(0, dim(data)[1])
data$left2 <- ifelse(data[,3]==2010 & data[,4]>=4 ,1,data$left2)
data$left2 <- ifelse(data[,3]>=2011 & data[,3]<=2015,1,data$left2)
data$left2 <- ifelse(data[,3]==2016 & data[,4]<=3 ,1,data$left2)

data$left <- data$left1+ data$left2


#lags and first differences

vars <- c('ntloss.mv', 'ntloss', 'nt.loss.poor','nt.loss.poor.mvdeo', 'nt.loss.nonpoor.mvdeo') 
data[, vars] <- data[, vars]*100

varlist <- c('left','ntloss.MWh.mv', 'ntloss.MWh', 'ntloss.mv', 'ntloss', 'nt.loss.poor',
      'nt.loss.poor.mvdeo', 'nt.loss.nonpoor.mvdeo', 'nt.loss.MWh.year.poor', 'nt.loss.MWh.year.nonpoor', 
      'td.MWh.year.mvdeo', 'ntloss.pnp', 'ntloss.pnp.mv', 'household.clients.total', 'unempl.mvdeo.des' )
n.lag <- 1
for (i in varlist) {
l.var  <- as.data.frame(c(rep(NA,n.lag), data[i][1:(dim(data[i])[1]-n.lag),]))
colnames(l.var) <- paste('l.', i, sep='')
data <- cbind(data, l.var)
d.var <- data[i] - data[colnames(l.var)]
colnames(d.var) <- paste('d.', i, sep='')
data <- cbind(data, d.var)
l.d.var  <- as.data.frame(c(rep(NA,n.lag), d.var[1:(dim(d.var)[1]-n.lag),]))
colnames(l.d.var) <- paste('l.d.', i, sep='')
data <- cbind(data, l.d.var)
}
n.lag <- 2
for (i in varlist) {
l2.var  <- as.data.frame(c(rep(NA,n.lag), data[i][1:(dim(data[i])[1]-n.lag),]))
colnames(l2.var) <- paste('l2.', i, sep='')
data <- cbind(data, l2.var)
}
#econ variables
varlist <- c('unempl.mvdeo.ma', "unempl.mvdeo")
n.lag <- 1
for (i in varlist) {
l.var  <- as.data.frame(c(rep(NA,n.lag), data[i][1:(dim(data[i])[1]-n.lag),]))
colnames(l.var) <- paste('l.', i, sep='')
data <- cbind(data, l.var)
d.var <- data[i] - data[colnames(l.var)]
colnames(d.var) <- paste('d.', i, sep='')
data <- cbind(data, d.var)
}
for (i in 1:12) {
n.lag <- i
lagvar <- c(rep(NA,n.lag), data$unempl.mvdeo.ma[1:(length(data$unempl.mvdeo.ma)-n.lag)])
data <- cbind(data, lagvar)
names(data) <- c(names(data)[1:(dim(data)[2]-1)], paste('l', i, '.unempl.mvdeo.ma', sep=""))
}

for (i in 1:12) {
n.lag <- i
lagvar <- c(rep(NA,n.lag), data$unempl.mvdeo[1:(length(data$unempl.mvdeo)-n.lag)])
data <- cbind(data, lagvar)
names(data) <- c(names(data)[1:(dim(data)[2]-1)], paste('l', i, '.unempl.mvdeo', sep=""))
}

for (i in 1:12) {
n.lag <- i
lagvar <- c(rep(NA,n.lag), data$left[1:(length(data$left)-n.lag)])
data <- cbind(data, lagvar)
names(data) <- c(names(data)[1:(dim(data)[2]-1)], paste('l', i, '.left', sep=""))
}


# ---- Figure 3 ----

vars <-c('date', 'month', 'year', 'ntloss.mv','unempl.mvdeo.ma')
data.plot <- data[, vars]
data.plot <- data.plot[complete.cases(data.plot),]
data.plot <- ts(data.plot, frequency=12, start=c(1998,1))
colnames(data.plot)[4:5]<-c('Electricity Losses', 'Unemployment rate')
pdf('./Figure3.pdf')
plot.ts(data.plot[,4:5],
      main='',
      ) 
dev.off()


# ---- Figure 4 ----

vars <-c('date', 'month', 'year','nt.loss.poor.mvdeo','nt.loss.nonpoor.mvdeo')
data.plot <- data[, vars]
data.plot <- data.plot[complete.cases(data.plot),]
data.plot <- ts(data.plot, frequency=12, start=c(1998,1))
pdf('./Figure4.pdf')
ts.plot(data.plot[,4:5],
    # ylim=c(0,12),
      ylab='Non-technical losses as % of consumed energy',
      lty=c(1,2))
rect(2002.5, 0,  2003.3, 12, col= rgb(.311,.311,.311,alpha=0.2), border=NA)
legend('bottomleft', c('Slum areas', 'Residential areas'),lty=c(1,2), cex=1)
abline(v=2005.25, col="blue", lty=2, lwd=c(1))
# text(2001,11, "Right Government", cex=1)
text(2007.5,1, "Left Government" , cex=1)
dev.off()


# ---- Table 1 ----
# create time series data
data.ts <- ts(data, frequency=12, start=c(1995,1))

lm0 <- lm(d.ntloss.mv ~ 
      1 + l.ntloss.mv + l.d.ntloss.mv 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      # + left
      # + election
      # + time.trend  
      # + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm0))
bgtest(lm0)


lm0b <- lm(d.ntloss.mv ~ 
      1 + l.ntloss.mv + l.d.ntloss.mv 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      + left
      + election
      # + time.trend  
      + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm0b))
bgtest(lm0)


lm1 <- lm(d.nt.loss.poor.mvdeo ~ 
      1 + l.nt.loss.poor.mvdeo + l.d.nt.loss.poor.mvdeo 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      # + left
      # + election
      # + time.trend  
      + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm1))
bgtest(lm1)


lm1b <- lm(d.nt.loss.poor.mvdeo ~ 
      1 + l.nt.loss.poor.mvdeo + l.d.nt.loss.poor.mvdeo 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      + left
      + election
      # + time.trend  
      + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm1b))
bgtest(lm1b)


lm2 <- lm(d.nt.loss.nonpoor.mvdeo ~ 
      1 + l.nt.loss.nonpoor.mvdeo + l.d.nt.loss.nonpoor.mvdeo 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      # + left
      # + election
      # + time.trend  
      + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm2))
bgtest(lm2)


lm2b <- lm(d.nt.loss.nonpoor.mvdeo ~ 
      1 + l.nt.loss.nonpoor.mvdeo + l.d.nt.loss.nonpoor.mvdeo 
      + l.unempl.mvdeo.ma
      + d.unempl.mvdeo.ma
      + left
      + election
      # + time.trend  
      + as.factor(month) 
      # + as.factor(year)
      , data=data.ts)
print(summary(lm2b))
bgtest(lm2b)


table1 <- screenreg(list(lm0, lm0b, lm1, lm1b, lm2, lm2b),
      # file= "./ts.html",
      label="tab:1",
      custom.model.names = c('Total losses', 'Total losses', 
            'Slum areas', 'Slum areas', 'Regular areas', 'Regular areas'),
      caption="ciclicality of light emision in legal settlements and slums in Montevideo, 1992-2010",
      dcolumn = TRUE,
      no.margin=FALSE,
      # fontsize="scriptsize",
      scalebox = 1,
      single.row=TRUE,
      use.packages=FALSE,
      booktabs = TRUE,
      digits=2,
      float.pos="htbp",
      sideways=FALSE,
      include.rsquared = FALSE,
      stars = c(0.01, 0.05, 0.1),
      custom.note= paste("%stars."))

table1



# ---- APPENDIX ----

# ---- Figure 1A ----

gps <- c(20.7, 22.4, 22.8, 20.8, 19.5, 19.7, 20.9, 22.8, 23, 24.2, 24.5, 24.3)
unemp <- c(13.6,15.3,17.0,16.9,13.1,12.2,11.3,9.8,8.3,8.2,7.5,6.6)
gdp <- c(8997.660125, 8636.545268, 7967.162567, 8036.479226, 8442.549558, 9068.239212, 9424.516994, 10014.87202, 10698.05202, 11112.45603, 11938.212, 12512.91348) 
gp <- c(26.55093188,27.27020301,27.89109917,27.912726,26.59172531,26.55718215,26.86393189,26.49277678,25.60302198,29.13316717,29.42013216,29.12060509)
year <- 2000:2011

pdf('./Figure1A.pdf')
plot(year, gps,
     xlim = c(2000, 2011),
     ylim = c(18, 25),
     ylab="Social Spending as % of GDP",  
     xlab="Year", 
     axes = FALSE, 
	 # pch = 19,
	 col="black",
	type="l",
	lty=c(1)
	)
axis(1, at= seq(1998,2011,1))
axis(2)
dev.off()




# ---- Figure 1B ----

year <- 2000:2011
forbearance <- c(NA,NA,10554.08971,7547.169811,NA,NA,NA,NA,14687.5,16467.53247,12710.52632,NA)
unemp <- c(13.6,15.3,17.0,16.9,13.1,12.2,11.3,9.8,8.3,8.2,7.5,6.6)

pdf('./Figure1B.pdf')
plot(unemp,forbearance,
     xlim = c(6, 18),
     ylim = c(5000, 18000),
     ylab="Inspections per point of non-thecnical losses (national)",  
     xlab="Unemployment rate (urban national)", 
     # axes = FALSE, 
	 pch = 19,
	 col="black",
	# type="l",
	lty=c(1)
	)
axis(1, at= seq(1998,2011,1))
axis(2)
reg <-lm(forbearance~unemp)
abline(reg)
text(unemp+.5,forbearance, labels=year, cex= 0.7)
dev.off()




