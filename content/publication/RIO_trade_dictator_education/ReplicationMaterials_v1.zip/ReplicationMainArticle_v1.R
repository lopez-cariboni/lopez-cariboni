#  Replicaiton code for López-Cariboni & Cao : "When do When Do Authoritarian Rulers Educate: Trade Competition and Human Capital Investment in Non-Democracies"
#  April 2018

rm(list=ls())
wd <- '~/Dropbox/Research/Publications/Education/ReplicationMaterials' # Please, choose a working directory on your computer here 
setwd(wd)

# ====================================
# = packages and functions, and data =
# ====================================

# Packages and functions
source('functions/plot.interaction.R')
source('functions/plot.interaction.2cat.R')
source('functions/plot.interaction.3cat.R')

# install.packages('plm', 'foreign')
library(plm)
library(foreign)
library(texreg)

# Load data
data <- read.csv('data/data.csv')
# Subset on non-democracies
data.subset <- subset(data, polity2<=6)


# ================================
# =           ANALYSIS           =
# ================================


# =============================
# = TABLE 1 : Interdependence =
# =============================

# Model 1 
fmla.11 <- dynformula(as.formula(diff(edugdpWBas, 1) ~  lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + diff(w.edugdpWBas) ))
m.11 <- plm(fmla.11, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m.11)

# Model 1 - LRM
fmla.11.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + diff(w.edugdpWBas, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m.11.lrm <- plm(fmla.11.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m.11.lrm)

# Model 2
fmla.12 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + diff(w.edugdpWBas) + lag(wreg.edugdpWBas, 1) + diff(wreg.edugdpWBas) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m.12 <- plm(fmla.12, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m.12)

# Model 2 - LRM
fmla.12.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + diff(w.edugdpWBas) + lag(wreg.edugdpWBas, 1) + diff(wreg.edugdpWBas) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m.12.lrm <- plm(fmla.12.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m.12.lrm)

# Table print. Note: only coefficients fron laged levels of IVs (not the changes) are interpretable in LRM columns
screenreg(list(m.11, m.11.lrm, m.12, m.12.lrm),
	custom.model.names = c('Model 1', 'LRM', 'Model 2', 'LRM'),
	caption='Trade Competition and Education Spending in Non-Democracies (1971-2009)',
	single.row=TRUE,
	digits=2,
	include.rsquared = FALSE,
	stars = c(0.01, 0.05, 0.1))

# ================================
# =     Table 2 : Resources      =
# ================================

# Oil
oil <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(oillgdp.log,1) + diff(oillgdp.log, 1) + lag(I(oillgdp.log*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m1.oil <- plm(oil, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m1.oil)

# Oil : LRM
oil.lrm <- dynformula(as.formula(edugdpWBas~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(oillgdp.log,1)  + diff(oillgdp.log, 1) + lag(I(oillgdp.log*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m1.oil.lrm <- plm(oil.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.oil.lrm)

# Naural Resources
resources <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(resources.log,1) + diff(resources.log, 1) + lag(I(resources.log*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m2.resources <- plm(resources, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m2.resources)


# Naural Resources : LRM
resources.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(resources.log,1)  + diff(resources.log, 1) + lag(I(resources.log*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.resources.lrm <- plm(resources.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m2.resources.lrm)

# Non-tax Revenue
nontax <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(nontaxtotalgdp, 1) + lag(I(nontaxtotalgdp*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m3.nontax <- plm(nontax, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m3.nontax)

# Non-tax Revenue: LRM
nontax.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(nontaxtotalgdp, 1) + lag(I(nontaxtotalgdp*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)  + diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m3.nontax.lrm <- plm(nontax.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m3.nontax.lrm)


screenreg(list(m1.oil, m1.oil.lrm, m2.resources, m2.resources.lrm, m3.nontax, m3.nontax.lrm),
	custom.model.names = c('Oil', 'LRM', 'Nat. Resources', 'LRM', 'Non-tax Revenue', 'LRM'),
	caption='Conditional Competition in Education Spending: Oil, Natural Resources, and Non-tax Revenue.',
	single.row=TRUE,
	include.rsquared = FALSE,
	stars = c(0.01, 0.05, 0.1))

# ================================
# =     Figure 3 : Resources     =
# ================================

# Oil Rents
plot.interaction(model.name=m1.oil.lrm, Z='lag(oillgdp.log, 1)', XZ='lag(I(oillgdp.log * w.edugdpWBas), 1)', X='lag(w.edugdpWBas, 1)', Xvar.name =	'Export Competition', Zvar.name =	'Oil Rents (log % GDP)', Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$oillgdp.log, Z.hist = TRUE)
plot.interaction(model.name=m1.oil.lrm, X='lag(oillgdp.log, 1)', XZ='lag(I(oillgdp.log * w.edugdpWBas), 1)', Z='lag(w.edugdpWBas, 1)', Zvar.name =	'Export Competition', Xvar.name =	'Oil Rents', Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$w.edugdpWBas, Z.hist = TRUE)

# Natural Resources
plot.interaction(model.name=m2.resources.lrm, Z='lag(resources.log, 1)', XZ='lag(I(resources.log * w.edugdpWBas), 1)', X='lag(w.edugdpWBas, 1)', Xvar.name =	'Export Competition', Zvar.name =	'Natural Resource Rents (log % GDP)', Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$resources.log, Z.hist = TRUE)
plot.interaction(model.name=m2.resources.lrm, X='lag(resources.log, 1)', XZ='lag(I(resources.log * w.edugdpWBas), 1)', Z='lag(w.edugdpWBas, 1)', Zvar.name =	'Export Competition', Xvar.name =	'Natural Resource Rents', Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$w.edugdpWBas, Z.hist = TRUE)

# Non-Tax Revenue
plot.interaction(model.name=m3.nontax.lrm, Z='lag(nontaxtotalgdp, 1)', XZ='lag(I(nontaxtotalgdp * w.edugdpWBas), 1)', X='lag(w.edugdpWBas, 1)', Xvar.name =	'Export Competition', Zvar.name =	'Non-tax revenue (% of GDP)', ylim=c(-10,5), Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$nontaxtotalgdpip, Z.hist = TRUE)
plot.interaction(model.name=m3.nontax.lrm, X='lag(nontaxtotalgdp, 1)', XZ='lag(I(nontaxtotalgdp * w.edugdpWBas), 1)', Z='lag(w.edugdpWBas, 1)', Zvar.name =	'Export Competition', Xvar.name =	'Non-tax Revenue', ylim=c(-.15,.05), Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$w.edugdpWBas, Z.hist = TRUE)



# ================================
# =    Table 3: Time-horizons    =
# ================================

# Model 1 
timehor1 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(fail,1) + diff(fail, 1) + lag(I(fail*w.edugdpWBas), 1) ))
m1.timehor <- plm(timehor1, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m1.timehor)

# Model 1 : LRM
timehor1.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(fail,1) + diff(fail, 1) + lag(I(fail*w.edugdpWBas), 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m1.timehor.lrm <- plm(timehor1.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.timehor.lrm)

# Model 2 
timehor2 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(fail,1) + diff(fail, 1) + lag(I(fail*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1) + diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) ))
m2.timehor <- plm(timehor2, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m2.timehor)

# Model 2 : LRM
timehor2.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(fail, 1) + diff(fail, 1) + lag(I(fail*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1) + diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.timehor.lrm <- plm(timehor2.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.timehor.lrm)

# Model 3
timehor3 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(lifetime,1) + diff(lifetime, 1) + lag(I(lifetime*w.edugdpWBas), 1) ))
m3.timehor <- plm(timehor3, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m3.timehor)

# Model 3 : LRM
timehor3.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(lifetime,1) + diff(lifetime, 1) + lag(I(lifetime*w.edugdpWBas), 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m3.timehor.lrm <- plm(timehor3.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m3.timehor.lrm)


# Model 4
timehor4 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(lifetime,1) + diff(lifetime, 1) + lag(I(lifetime*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1) + diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) ))
m4.timehor <- plm(timehor4, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m4.timehor)

# Model 4 : LRM
timehor4.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(lifetime, 1) + diff(lifetime, 1) + lag(I(lifetime*w.edugdpWBas), 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)  + diff(urbpop, 1) + lag(log(pop_total), 1)  + diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1) + diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m4.timehor.lrm <- plm(timehor4.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m4.timehor.lrm)


screenreg(list(m1.timehor, m1.timehor.lrm, m2.timehor, m2.timehor.lrm, m3.timehor, m3.timehor.lrm, m4.timehor, m4.timehor.lrm),
	custom.model.names = c('Model 1', 'LRM', 'Model 2', 'LRM', 'Model 3', 'LRM', 'Model 4', 'LRM'),
	caption='Conditional Competition in Education Spending: Rulers Time-horizons',
	single.row=TRUE,
	digits=2,
	include.rsquared = FALSE,
	stars = c(0.01, 0.05, 0.1))


# ================================
# =     Figure 4: Time-horizons  =
# ================================

#Regime Faliure
plot.interaction(model.name=m2.timehor.lrm, Z='lag(fail, 1)', XZ='lag(I(fail * w.edugdpWBas), 1)', X='lag(w.edugdpWBas, 1)', Xvar.name =	'Export Competition', Zvar.name =	'Probability of regime failure', Xaxis.log=FALSE, Z.log=FALSE, ylim = c(-10,5), Zorigin=data.subset$fail, Z.hist = TRUE)
plot.interaction(model.name=m2.timehor.lrm, X='lag(fail, 1)', XZ='lag(I(fail * w.edugdpWBas), 1)', Z='lag(w.edugdpWBas, 1)', Zvar.name =	'Export Competition', Xvar.name =	'Probability of regime failure', Xaxis.log=FALSE, Z.log=FALSE, ylim = c(-40,20), Zorigin=data.subset$w.edugdpWBas, Z.hist = TRUE)

#Regime Duration
plot.interaction(model.name=m4.timehor.lrm, Z='lag(lifetime, 1)', XZ='lag(I(lifetime * w.edugdpWBas), 1)', X='lag(w.edugdpWBas, 1)', Xvar.name =	'Export Competition', Zvar.name =	'Regime duration', Xaxis.log=FALSE, Z.log=FALSE, ylim=c(-2,4), Zorigin=data.subset$lifetime, Z.hist = TRUE)
plot.interaction(model.name=m4.timehor.lrm, X='lag(lifetime, 1)', XZ='lag(I(lifetime * w.edugdpWBas), 1)', Z='lag(w.edugdpWBas, 1)', Zvar.name =	'Export Competition', Xvar.name =	'Regime duration', Xaxis.log=FALSE, Z.log=FALSE, Zorigin=data.subset$w.edugdpWBas, Z.hist = TRUE)



# ================================
# =    Table 4: Single Party     =
# ================================

# Model 1
sparty <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(gwf_party,1)  + diff(gwf_party, 1) + I(lag(gwf_party)*lag(w.edugdpWBas)) ))
m1.sparty <- plm(sparty, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m1.sparty)

# Model 1 : LRM
sparty2.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(gwf_party,1) + diff(gwf_party, 1) + I(lag(gwf_party,1)*lag(w.edugdpWBas,1)) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.sparty.lrm <- plm(sparty2.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.sparty.lrm)

# Model 2
sparty <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(gwf_party,1) + diff(gwf_party, 1) + I(lag(gwf_party)*lag(w.edugdpWBas)) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1)+ diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1) + diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) ))
m3.sparty <- plm(sparty, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m3.sparty)

# Model 2 : LRM
sparty4.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(gwf_party,1) + diff(gwf_party, 1) + I(lag(gwf_party,1)*lag(w.edugdpWBas,1)) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1)+ diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1) + diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) )) 
m4.sparty.lrm <- plm(sparty4.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year')) 
# summary(m4.sparty.lrm)


screenreg(list(m1.sparty, m2.sparty.lrm, m3.sparty, m4.sparty.lrm),
        custom.model.names = c('Model 1', 'LRM', 'Model 2', 'LRM'),
        caption='Conditional Competition in Education Spending: Single-Party Regimes',
        single.row=TRUE,
        digits=2,
        include.rsquared = FALSE,
        stars = c(0.01, 0.05, 0.1))

# ================================
# =   Figure 5 : Single Party    =
# ================================

plot.interaction.nominal(X = 'lag(w.edugdpWBas, 1)', Z='lag(gwf_party, 1)', XZ='I(lag(gwf_party, 1) * lag(w.edugdpWBas, 1))', model.name=m4.sparty.lrm, Z.nominal=T, categories=c('Other Regimes', 'Single-Party Reg.'), Xvar.name='Trade Competition', Zvar.name='')


# ================================
# =    Table 5: Legislature      =
# ================================

# Model 1
legislature <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(legislature,1) + diff(legislature, 1) + I(lag(legislature)*lag(w.edugdpWBas)) ))
m1.legislature <- plm(legislature, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.legislature)

# Model 1 : LRM
legislature2.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(legislature,1)+ diff(legislature, 1) + I(lag(legislature,1)*lag(w.edugdpWBas,1)) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.legislature.lrm <- plm(legislature2.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.legislature.lrm)

# Model 2
legislature <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1)+ lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(legislature,1)+ diff(legislature, 1) + I(lag(legislature)*lag(w.edugdpWBas)) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) )) 
m3.legislature <- plm(legislature, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m3.legislature)

# Model 2 : LRM
legislature4.lrm <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(diff(edugdpWBas, 1),1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(legislature,1)+ diff(legislature, 1) + I(lag(legislature,1)*lag(w.edugdpWBas,1)) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(polity2, 1) + diff(polity2, 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1)+ diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m4.legislature.lrm <- plm(legislature4.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m4.legislature.lrm)

screenreg(list(m1.legislature, m2.legislature.lrm, m3.legislature, m4.legislature.lrm),
        custom.model.names = c('Model 1', 'LRM', 'Model 2', 'LRM'),
        caption='Conditional Competition in Education Spending: Authoritarian Legislatures',
        single.row=TRUE,
        digits=2,
        include.rsquared = FALSE,
        stars = c(0.01, 0.05, 0.1))


# ================================
# =    Figure 6: Legislature     =
# ================================

plot.interaction.nominal(X = 'lag(w.edugdpWBas, 1)', Z='lag(legislature, 1)', XZ='I(lag(legislature, 1) * lag(w.edugdpWBas, 1))', model.name=m4.legislature.lrm, Z.nominal=T, categories=c('No Legislautre', 'Legislature'), Xvar.name='Trade Competition', Zvar.name='')


# ===================================
# = Table 6: Partisan Legsislatures =
# ===================================

# Model 1
partisan.leg <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1)            + lag(diff(edugdpWBas), 1) + lag(w.edugdpWBas, 1) + lag(partisan.leg,1)           + diff(partisan.leg, 1) + I(lag(partisan.leg,1)*lag(w.edugdpWBas,1)) ))
m1.partisan.leg <- plm(partisan.leg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.partisan.leg)

# Model 1: LRM
partisan.leg.lrm <- dynformula(as.formula(edugdpWBas~ diff(edugdpWBas, 1)+ lag(diff(edugdpWBas), 1) + lag(w.edugdpWBas, 1) + lag(partisan.leg,1) + diff(partisan.leg, 1) + I(lag(partisan.leg,1)*lag(w.edugdpWBas,1)) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m1.partisan.leg.lrm <- plm(partisan.leg.lrm, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.partisan.leg.lrm)

# Model 2
partisan.leg <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(partisan.leg,1) + diff(partisan.leg, 1) + I(lag(partisan.leg,1)*lag(w.edugdpWBas,1)) + lag(polity2, 1) + diff(polity2, 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m2.partisan.leg <- plm(partisan.leg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.partisan.leg)

# Model 2: LRM
partisan.leg <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(partisan.leg,1) + diff(partisan.leg, 1) + I(lag(partisan.leg,1)*lag(w.edugdpWBas,1)) + lag(polity2, 1) + diff(polity2, 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.partisan.leg.lrm <- plm(partisan.leg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.partisan.leg.lrm)

# Model 3
spmpleg <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(spleg,1)+ diff(spleg, 1) + I(lag(spleg,1)*lag(w.edugdpWBas,1)) + lag(mpleg,1)+ diff(mpleg, 1) + I(lag(mpleg,1)*lag(w.edugdpWBas,1)) ))
m1.spmpleg <- plm(spmpleg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.spmpleg)

# Model 3: LRM
spmpleg <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(spleg,1)+ diff(spleg, 1) + I(lag(spleg,1)*lag(w.edugdpWBas,1)) + lag(mpleg,1)+ diff(mpleg, 1) + I(lag(mpleg,1)*lag(w.edugdpWBas,1)) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m1.spmpleg.lrm <- plm(spmpleg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m1.spmpleg.lrm)

# Model 4
spmpleg <- dynformula(as.formula(diff(edugdpWBas, 1) ~ lag(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(spleg,1)+ diff(spleg, 1) + I(lag(spleg,1)*lag(w.edugdpWBas,1)) + lag(mpleg,1)+ diff(mpleg, 1) + I(lag(mpleg,1)*lag(w.edugdpWBas,1)) + lag(polity2, 1) + diff(polity2, 1) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) ))
m2.spmpleg <- plm(spmpleg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.spmpleg)

# Model 4 : LRM
spmpleg <- dynformula(as.formula(edugdpWBas ~ diff(edugdpWBas, 1) + lag(w.edugdpWBas, 1) + lag(wreg.edugdpWBas, 1) + lag(spleg,1)+ diff(spleg, 1) + I(lag(spleg,1)*lag(w.edugdpWBas,1)) + lag(polity2, 1) + diff(polity2, 1) + lag(mpleg,1)+ diff(mpleg, 1) + I(lag(mpleg,1)*lag(w.edugdpWBas,1)) + lag(log(importsgdp), 1) + diff(log(importsgdp), 1) + lag(log(exportsgdp), 1) + diff(log(exportsgdp), 1) + lag(pop014pct, 1) + diff(pop014pct, 1) + lag(urbpop, 1)+ diff(urbpop, 1) + lag(log(pop_total), 1)+ diff(log(pop_total), 1) + lag(gdppcconstus,1) + diff(gdppcconstus,1) + lag(govconsgdp, 1)+ diff(govconsgdp, 1) + lag(outputgap_pc002, 1) + diff(outputgap_pc002, 1) | . - diff(edugdpWBas, 1) + lag(edugdpWBas, 1) ))
m2.spmpleg.lrm <- plm(spmpleg, effect='twoways', data=data.subset, na.action=na.omit, index = c('iso3c','year'))
# summary(m2.spmpleg.lrm)


screenreg(list(m1.partisan.leg, m1.partisan.leg.lrm, 
	m2.partisan.leg, m2.partisan.leg.lrm, 
	m1.spmpleg, m1.spmpleg.lrm, 
	m2.spmpleg, m2.spmpleg.lrm),
	custom.model.names = c('Model 1', 'LRM', 'Model 2', 'LRM', 'Model 3', 'LRM', 'Model 4', 'LRM'),
	caption='Conditional Competition in Education Spending: Partisan Legislatures',
	single.row=TRUE,
	digits=2,
	include.rsquared = FALSE,
	stars = c(0.01, 0.05, 0.1))

# ================================
# =    Figure 7: Legislature     =
# ================================

PlotInteraction.3cat(X = 'lag(w.edugdpWBas, 1)', Y='lag(mpleg, 1)', XY='I(lag(mpleg, 1) * lag(w.edugdpWBas, 1))', Z = 'lag(spleg, 1)', XZ = 'I(lag(spleg, 1) * lag(w.edugdpWBas, 1))', Z.nominal=TRUE, categories=c('No partsian \n legislature', 'Single-party \n legislature', 'Multiparty \n legislature'), model.name=m2.spmpleg.lrm, Xvar.name='Trade Competition', Zvar.name='')


