# Lag panel data
# Thanks to Chris Adolph!

# Usage:
#
# laggeddata <- lagpanel(x,  # An n x k matrix of data to be lagged;
                             # must be in time series order and stacked by
                             # unit
#                        c,  # An n x 1 vector of group numbers
#                        t,  # An n x 1 vector of periods
#                        lagnum, # The desired lag to report

lagpanel <- function(x,c,t,lagnum) {
    x <- as.matrix(x)
    c <- as.matrix(c)
    t <- as.matrix(t)
    listc <- unique(c)
    outmat <- matrix(NA,nrow=nrow(x),ncol=ncol(x))
    runningtotal <- 0
    for (i in 1:nrow(listc)) {
        numtper <- length(unique(t[c==listc[i,]]))
        xc <- as.matrix(x[c==listc[i,],])
        if (numtper>lagnum) {
            outmat[(runningtotal+1+lagnum):(runningtotal + numtper),] <-
                xc[1:(nrow(xc)-lagnum),]
        }
        runningtotal <- runningtotal + numtper
    }
    outmat
}
