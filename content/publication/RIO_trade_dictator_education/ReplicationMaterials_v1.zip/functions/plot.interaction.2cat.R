# An R function to plot interaction effects from regression models. 
# Description: This function plots interaction effects for a 2 catergories modifying variable

plot.interaction.nominal <- function(X, Z, XZ, model.name, 
							xlog=FALSE, Z.nominal=FALSE, 
							categories=FALSE,
							Xvar.name=FALSE,
							Zvar.name=FALSE, 
							level=0.95) {
	model <- model.name
	t.value <- qt(0.975, df=df.residual(model))
	t.value <- ifelse(level==0.90, qt( 0.95, df=df.residual(model)), t.value)
	# betas <- names(coefficients(model))
	v1  <- X
	v2  <- Z
	v1v2  <- XZ

	b1 <- coefficients(model)[v1]
	b2 <- coefficients(model)[v2]
	b3 <- coefficients(model)[v1v2]

	varb1  <- vcov(model)[v1, v1]
	varb2  <- vcov(model)[v2, v2]
	varb3  <- vcov(model)[v1v2, v1v2]
	covb1b3 <- vcov(model)[v1, v1v2]

	Z.var <- as.numeric(model$model[,names(b2)])
	min <- summary(Z.var)[c("Min.")]
	max <- summary(Z.var)[c("Max.")]
	mod.z <- seq(min, max, length.out=200)
	mar.eff.b1 <- b1+b3*mod.z
	se.mef.b1 <- sqrt(varb1+varb3*(mod.z^2)+2*covb1b3*mod.z) 
	ci.upper <-  mar.eff.b1 + t.value*se.mef.b1
	ci.lower <-  mar.eff.b1 - t.value *se.mef.b1

	par(mfrow=c(1, 1), mar=c(3,3,2,2), mgp=c(2,.5,0), las=1, oma=c(0, 0, 0, 0), 
		cex.axis=1, cex.lab=1)
	# pdf("int.pdf", width=6, height=6)

	if(xlog=="TRUE"){plot(mod.z, mar.eff.b1,
			# ylim = c(min(ci.lower)-sqrt(var(mar.eff.b1)),max(ci.upper)+sqrt(var(mar.eff.b1))),
			ylim = c(-2,1),
			# xlim = range(mod.z),
			axes=FALSE, 
			type="l", lty=1,  col=gray(.4),
			ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, 
													names(b1),
													Xvar.name), sep=" "),
			xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
			log= "x", 
			xpd = TRUE)
        }
        else{if(Z.nominal=="TRUE"){plot(c(mod.z[1],mod.z[length(mod.z)]),
        c(mar.eff.b1[1],mar.eff.b1[length(mar.eff.b1)]),
		ylim = c(min(ci.lower)-sqrt(var(mar.eff.b1)),
        max(ci.upper)+sqrt(var(mar.eff.b1))),
        xlim = range(min(mod.z)-.5, max(mod.z)+.5),
		axes=FALSE, 
		type="p", lty=1,  col="black",
		ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, 
													names(b1),
													Xvar.name), sep=" "),
		xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
		xpd = TRUE)
        }
        	else{plot(mod.z, mar.eff.b1,
	    	ylim = c(min(ci.lower)-sqrt(var(mar.eff.b1)), 
        	max(ci.upper)+sqrt(var(mar.eff.b1))),
	    	# xlim = range(mod.z),
	    	axes=FALSE, 
	    	type="l", lty=1,  col=gray(.4),
	    	ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, 
													names(b1),
													Xvar.name), sep=" "),
	    xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
	    xpd = TRUE)
        }
    }
	abline (0,0,lwd=.5, lty=2)
	if(xlog=="TRUE"){lines(mod.z, ci.upper, cex=1, lty=2, col="black")
                     lines(mod.z, ci.lower, cex=1, lty=2, col="black")}
    else{if(Z.nominal=="TRUE"){segments(c(mod.z[1], mod.z[length(mod.z)]),
                                c(ci.lower[1], ci.lower[length(ci.lower)]),
                                c(mod.z[1], mod.z[length(mod.z)]),
                                c(ci.upper[1],ci.upper[length(ci.upper)]), 
                                cex=1, lty=1, col="black")}
    	else{lines(mod.z, ci.upper, cex=1, lty=2, col="black")
         	 lines(mod.z, ci.lower, cex=1, lty=2, col="black")
         	}
         }  
    if(Z.nominal=="TRUE"){
        axis(1, c(mod.z[1], mod.z[length(mod.z)]), 
        	ifelse(categories==FALSE, FALSE, categories))
        axis(2, )}
        else{axis(1, )
             axis(2, )}
	# dev.off()
	}    
