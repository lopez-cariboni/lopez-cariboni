# An R function to plot interaction effects from regression models. 
# Description: This function plots interaction effects for a 3 catergories modifying variable

PlotInteraction.3cat <- function(X, Z, Y, XZ, XY, model.name, 
							xlog=FALSE, Z.nominal=FALSE, 
							categories=FALSE,
							Xvar.name=FALSE,
							Zvar.name=FALSE) {
	model <- model.name
	# betas <- names(coefficients(model))
	v1  <- X
	v2  <- Z
	v3  <- Y
	v1v2  <- XZ
	v1v3  <- XY

	b1 <- coefficients(model)[v1]
	b2 <- coefficients(model)[v2]
	b3 <- coefficients(model)[v3]	
	b4 <- coefficients(model)[v1v2]
	b5 <- coefficients(model)[v1v3]

	varb1  <- vcov(model)[v1, v1]
	varb2  <- vcov(model)[v2, v2]
	varb3  <- vcov(model)[v3, v3]
	varb4  <- vcov(model)[v1v2, v1v2]
	varb5  <- vcov(model)[v1v3, v1v3]
	covb1b4 <- vcov(model)[v1, v1v2]
	covb1b5 <- vcov(model)[v1, v1v3]

	Z.var <- as.numeric(model$model[,names(b2)])
	min <- summary(Z.var)[c("Min.")]
	max <- summary(Z.var)[c("Max.")]
	mod.z <- seq(min, max)
	mar.eff.b1 <- b1+b4*mod.z
	se.mef.b1 <- sqrt(varb1+varb4*(mod.z^2)+2*covb1b4*mod.z) 
	ci.upper.b1 <-  mar.eff.b1 + 1.96*se.mef.b1
	ci.lower.b1 <-  mar.eff.b1 - 1.96*se.mef.b1

	Y.var <- as.numeric(model$model[,names(b3)])
	min <- summary(Y.var)[c("Min.")]
	max <- summary(Y.var)[c("Max.")]
	mod.y <- seq(min, max)
	mar.eff.b3 <- b1+b5*mod.y
	se.mef.b3 <- sqrt(varb1+varb5*(mod.y^2)+2*covb1b5*mod.y) 
	ci.upper.b3 <-  mar.eff.b3 + 1.96*se.mef.b3
	ci.lower.b3 <-  mar.eff.b3 - 1.96*se.mef.b3

	mod <- seq(0, 2)
	mar.effects <- c(mar.eff.b1[1], mar.eff.b1[2], mar.eff.b3[2])
	ci.upper <-c(ci.upper.b1[1],ci.upper.b1[2], ci.upper.b3[2])
	ci.lower <-c(ci.lower.b1[1],ci.lower.b1[2], ci.lower.b3[2])

	par(mfrow=c(1, 1), mar=c(4,4,2,2), mgp=c(3,1.5,0), las=1, oma=c(1,1,1,1), 
		cex.axis=1, cex.lab=1)
	plot(mod, mar.effects,
	    	ylim = c(min(ci.lower)-sqrt(var(mar.effects)), 
        	max(ci.upper)+sqrt(var(mar.effects))),
        	xlim = range(min(mod)-.5, max(mod)+.5),
			axes=FALSE, 
			type="p", lty=1,  col="black",
	    	ylab = paste("Marginal Effect of", ifelse(Xvar.name==FALSE, 
													names(b1),
													Xvar.name), sep=" "),
	    	xlab = ifelse(Zvar.name==FALSE, names(b2), Zvar.name),
	    	xpd = TRUE)
        abline (0,0,lwd=.5, lty=2)
 		segments(0:2,c(ci.lower),0:2, ci.upper, cex=1, lty=1, col="black")
	    axis(1, 0:2, ifelse(categories==FALSE, FALSE, categories))
        axis(2, )
}    
