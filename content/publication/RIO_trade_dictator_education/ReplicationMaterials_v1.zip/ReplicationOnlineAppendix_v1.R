# R chunks for OnlineAppendix.Rnw


rm(list=ls())
wd <- '~/Dropbox/Research/Publications/Education/ReplicationMaterials' # Please, choose a working directory on your computer here 
setwd(wd)

# ====================================
# = packages and functions, and data =
# ====================================

# Packages and functions
source('functions/plot.interaction.R')
# install.packages('plm')
library(plm)
# install.packages('foreign')
library(foreign)
# install.packages('texreg')
library(texreg)
# install.packages('lmtest')
library(lmtest)
# install.packages('ggplot2')
library(ggplot2)


# Load data
data <- read.csv('data/data.csv')

# =================================================
# B Interdependence in human capital considering longer periods
# =================================================

# ===========
# = TABLE 1 =
# ===========

# ---- spat.lag.outcomes.spending ----
fmla.11 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)            
        + lag(w.edugdpWBas, 6)        + diff(lag(w.edugdpWBas,6))
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1)
        ))
m.11lag <- plm(fmla.11, effect='twoways',
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c('iso3c','year'))
# summary(m.11lag)
fmla.12 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)            
        + lag(w.edugdpWBas, 10)       + diff(lag(w.edugdpWBas,10))
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1)
        ))
m.12lag <- plm(fmla.12, effect='twoways',
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c('iso3c','year'))
# summary(m.12lag)

# Table print
screenreg(list(m.11lag, m.12lag),
    custom.model.names = c('Model 1', 'Model 2' ),
    caption='Trade Competition and Education Spending in Non-Democracies (1971-2009). Lagged effects considering theoretical duration of education.',
    single.row=TRUE,
    digits=2,
    include.rsquared = FALSE,
    stars = c(0.01, 0.05, 0.1),
    custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# =================================================
# C Competition and education spending in democracies
# =================================================

# ===========
# = TABLE 2 =
# ===========

# ---- demo ----
fmla.11 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
		lag(edugdpWBas, 1)              
		+ lag(w.edugdpWBas, 1)          + diff(w.edugdpWBas, 1)
		))
m.11.ldc <- plm(fmla.11, effect="twoways",
		  data=subset(data, polity2>=7 & LDC==1),
		  na.action=na.omit,
		  index = c("iso3c","year"))
m.11.dev <- plm(fmla.11, effect="twoways",
		  data=subset(data, LDC==0),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.12 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
		lag(edugdpWBas, 1)            
		+ lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
		+ lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.12.ldc <- plm(fmla.12, effect="twoways",
		  data=subset(data, polity2>=7 & LDC==1),
		  na.action=na.omit,
		  index = c("iso3c","year"))
m.12.dev <- plm(fmla.12, effect="twoways",
		  data=subset(data, LDC==0),
		  na.action=na.omit,
		  index = c("iso3c","year"))

# Table print
screenreg(list(m.11.ldc, m.12.ldc, m.11.dev, m.12.dev), 
label="tab:mdemo",
caption="Sample of democracies (subset(data, polity2$>=$7))",
custom.model.names = c('LDCs 1', 'LDCs 2', 'Developed 1', 'Developed 2'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# =================================================
# D Alternative measure for oil dependent countries
# =================================================

# ===========
# = FIGURE 2=
# ===========


# ---- RossOil ----
oil.lrm <- dynformula(as.formula(edugdpWBas~ 
        diff(edugdpWBas, 1)           
        + lag(w.edugdpWBas, 1)        
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(logoil_gas_valuepop_1,1) + diff(logoil_gas_valuepop_1, 1)
        + lag(I(logoil_gas_valuepop_1*w.edugdpWBas), 1) 
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1)
        | . - diff(edugdpWBas, 1)     + lag(edugdpWBas, 1)
        ))
m2.oil.lrm <- plm(oil.lrm, effect='twoways',
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c('iso3c','year'))
# summary(m2.oil.lrm)

plot.interaction(
    model.name=m2.oil.lrm, 
    Z='lag(logoil_gas_valuepop_1, 1)', 
    XZ='lag(I(logoil_gas_valuepop_1 * w.edugdpWBas), 1)',
    X='lag(w.edugdpWBas, 1)', 
    Xvar.name = 'Export Competition',
    Zvar.name = 'Oil and gas income per capita (Michel Ross)',
    Xaxis.log=FALSE, 
    Z.log=FALSE, 
    Zorigin=data$logoil_gas_valuepop_1,
    Z.hist = TRUE)

plot.interaction(
    model.name=m2.oil.lrm, 
    X='lag(logoil_gas_valuepop_1, 1)', 
    XZ='lag(I(logoil_gas_valuepop_1 * w.edugdpWBas), 1)',
    Z='lag(w.edugdpWBas, 1)', 
    Zvar.name = 'Export Competition',
    Xvar.name = 'Oil and gas income per capita (Ross)',
    Xaxis.log=FALSE, 
    Z.log=FALSE, 
    Zorigin=data$w.edugdpWBas,
    Z.hist = TRUE)



# =================================================
# E Collective action mechanisms
# =================================================

# ============
# = TABLE 3 =
	# ============

	# Elective legislature
	fmla.41 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(eleleg,1)  + diff(eleleg, 1)
	        + I(lag(eleleg,1)*lag(w.edugdpWBas,1))
	        ))
	m.41 <- plm(fmla.41, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	# summary(m.41)
	fmla.42 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(eleleg,1)  + diff(eleleg, 1)
	        + I(lag(eleleg,1)*lag(w.edugdpWBas,1))
			+ lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
	        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
	        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
	        + lag(polity2, 1)             + diff(polity2, 1)
	        + lag(pop014pct, 1)           + diff(pop014pct, 1)
	        + lag(urbpop, 1)              + diff(urbpop, 1)
	        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
	        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
	        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
	        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
			))
	m.42 <- plm(fmla.42, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	# summary(m.42)
	#legislature with competitive elections
	fmla.41b <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(GehlbachKeefer.compleg,1)  + diff(GehlbachKeefer.compleg, 1)
	        + I(lag(GehlbachKeefer.compleg,1)*lag(w.edugdpWBas,1))
			))
	m.41b <- plm(fmla.41b, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	fmla.42b <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(GehlbachKeefer.compleg,1)  + diff(GehlbachKeefer.compleg, 1)
	        + I(lag(GehlbachKeefer.compleg,1)*lag(w.edugdpWBas,1))
			+ lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
	        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
	        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
	        + lag(polity2, 1)             + diff(polity2, 1)
	        + lag(pop014pct, 1)           + diff(pop014pct, 1)
	        + lag(urbpop, 1)              + diff(urbpop, 1)
	        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
	        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
	        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
	        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
			))
	m.42b <- plm(fmla.42b, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	# Ruling party Institutionalization
	fmla.43 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(GehlbachKeefer.party.inst,1)  + diff(GehlbachKeefer.party.inst, 1)
	        + I(lag(GehlbachKeefer.party.inst,1)*lag(w.edugdpWBas,1))
			))
	m.43 <- plm(fmla.43, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	# summary(m.43)
	fmla.44 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(GehlbachKeefer.party.inst,1)  + diff(GehlbachKeefer.party.inst, 1)
	        + I(lag(GehlbachKeefer.party.inst,1)*lag(w.edugdpWBas,1))
	        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
	        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
	        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
	        + lag(polity2, 1)             + diff(polity2, 1)
	        + lag(pop014pct, 1)           + diff(pop014pct, 1)
	        + lag(urbpop, 1)              + diff(urbpop, 1)
	        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
	        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
	        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
	        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
			))
	m.44 <- plm(fmla.44, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	# summary(m.44)

	#Log of Strikes and Demonstrations data
	fmla.45 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(banks_strikes.log,1)  + diff(banks_strikes.log, 1)
	        + I(lag(banks_strikes.log,1)*lag(w.edugdpWBas,1))
	        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
	        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
	        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
	        + lag(polity2, 1)             + diff(polity2, 1)
	        + lag(pop014pct, 1)           + diff(pop014pct, 1)
	        + lag(urbpop, 1)              + diff(urbpop, 1)
	        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
	        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
	        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
	        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
			))
	m.45 <- plm(fmla.45, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))
	fmla.46 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
	        lag(edugdpWBas, 1)
	        + lag(w.edugdpWBas, 1)
	        + lag(banks_demonstrations.log,1)  + diff(banks_demonstrations.log, 1)
	        + I(lag(banks_demonstrations.log,1)*lag(w.edugdpWBas,1))
	        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
	        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
	        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
	        + lag(polity2, 1)             + diff(polity2, 1)
	        + lag(pop014pct, 1)           + diff(pop014pct, 1)
	        + lag(urbpop, 1)              + diff(urbpop, 1)
	        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
	        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
	        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
	        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
			))
	m.46 <- plm(fmla.46, model="within", effect="twoways",  
	  		  data=subset(data, polity2<=6),
			  na.action=na.omit,
			  index = c("iso3c","year"))

	# Table print
	screenreg(list(m.42, m.42b, m.44, m.45, m.46), 
	caption="Elective authoritarian legislatures, ruling-party institutionalization, and mass-mobilization",
	custom.model.names = c('Elective leg (spleg)', 'Elec.leg. (GehlbachKeefer)', 
		"Institutionalization", "Strikes", "Demonstrations"),
	single.row=TRUE,
	include.rsquared = FALSE,
	stars = c(0.01, 0.05, 0.1),
	sideways=TRUE,
	custom.note= paste("%stars.","Country and year fixed effects are included in the models."))


	# ============
# = TABLE 4 =
# ============

# ---- collaction.control ----
fmla.47 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(partisan.leg,1)  + diff(partisan.leg, 1)
        + I(lag(partisan.leg,1)*lag(w.edugdpWBas,1))
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(GehlbachKeefer.party.inst,1)  + diff(GehlbachKeefer.party.inst, 1)
        + lag(GehlbachKeefer.compleg,1)  + diff(GehlbachKeefer.compleg, 1)
        + lag(banks_demonstrations.log,1)  + diff(banks_demonstrations.log, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.47 <- plm(fmla.47, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.48 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(GehlbachKeefer.party.inst,1)  + diff(GehlbachKeefer.party.inst, 1)
        + lag(GehlbachKeefer.compleg,1)  + diff(GehlbachKeefer.compleg, 1)
        + lag(banks_demonstrations.log,1)  + diff(banks_demonstrations.log, 1)
        + lag(spleg,1)  + diff(spleg, 1)
        + I(lag(spleg,1)*lag(w.edugdpWBas,1))
        + lag(mpleg,1)  + diff(mpleg, 1)
        + I(lag(mpleg,1)*lag(w.edugdpWBas,1))
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.48 <- plm(fmla.48, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))

# Table print
screenreg(list(m.47, m.48), 
label="tab:colaction.control",
caption="Mediating Effects of partisan legislatures controlling for collective action institutions and mass-mobilization",
custom.model.names = c('Partisan legislature', 'Single/Multi-party legislature'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))


# =================================================
# F Education as cooptation
# =================================================

# ============
# = TABLE 5 =
# ============

# ---- exp_pupil ----
fmla.98 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(exppripupil, 10)
        + I(lag(exppripupil, 10)*lag(w.edugdpWBas, 1))
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.98 <- plm(fmla.98, model="within", effect="twoways",  
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
# summary(m.98)

fmla.99 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(expsecpupil, 10)
        + lag(expsecpupil, 10)*lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.99 <- plm(fmla.99, model="within", effect="twoways",  
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
# summary(m.99)

fmla.910 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)  
        + lag(expterpupil, 10)
        + lag(expterpupil, 10)*lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.910 <- plm(fmla.910, model="within", effect="twoways",  
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
# summary(m.910)

# Table print
screenreg(list(m.98, m.99, m.910), 
caption="Mediating effects of past levels of spending per pupil",
custom.model.names = c('Primary', 'Secondary', 'Tertiary'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# ============
# = FIGURE 3 =
# ============

# ---- plot_teacher_salaries ----
fmla.911 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + as.factor(iso3c):lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1)
        + as.factor(year)
        ))
m.911 <- plm(fmla.911, model="within",  
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
# summary(m.911)

#Extract interdependence by country 
countrylist <- as.character(names(fixef(m.911))) 
first <- grep(countrylist[1], names(coefficients(m.911)),value=FALSE)
last <- grep(countrylist[length(countrylist)], names(coefficients(m.911)),value=FALSE)
effects <- coefficients(m.911)[first:last]
names(effects) <- substr(names(effects), 17, 19)
effects <- data.frame(iso3c=names(effects),effects=as.numeric(effects))
# Take the country average teacher salaries/GDP 
# # install.packages('dplyr')
library(dplyr)
tech_salaries_pri_gdp <- data[data$polity2<=6,] %>%
  group_by(iso3c) %>%
  summarise(mean(tech_salaries_pri_gdp, na.rm=TRUE))
d <- merge(tech_salaries_pri_gdp, effects,by=c("iso3c"))
tech_salaries_sec_gdp <- data[data$polity2<=6,] %>%
  group_by(iso3c) %>%
  summarise(mean(tech_salaries_sec_gdp, na.rm=TRUE))
d <- merge(tech_salaries_sec_gdp, d,by=c("iso3c"))
names(d) <- c("iso3c", "tech_salaries_pri_gdp", "tech_salaries_sec_gdp", "interdependence")
detach("package:dplyr", unload=TRUE) # better not to work with the plm package and dplyr at the same time.
# Plot
plot(d$tech_salaries_pri_gdp,d$interdependence, 
    ylim= c(-1,1),
    ylab="Coefficient of interdependence",
    xlab="Teacher salaries as % of GDP",
    pch=19, 
    col='red')
points(d$tech_salaries_sec_gdp,d$interdependence,
    ylim= c(-1,1),
    pch=15, 
    col='blue')
abline(a=0, b=0)
legend('bottomright', legend=c('Primary education', 'Secondary education'), 
    pch = c(19,15), col=c('red','blue'), )



# ============
# = TABLE 6 =
# ============

# ---- cooptation_publicsector ----
fmla.91 <- dynformula(as.formula(diff(log(publicemployment_pop), 1) ~ 
        lag(log(publicemployment_pop), 1)
        + lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.91 <- plm(fmla.91, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
m.91sp <- plm(fmla.91, model="within", effect="twoways",  
          data=subset(data, polity2<=6 & gwf_party==1),
          na.action=na.omit,
          index = c("iso3c","year"))

# ---- Total_gov_spending ----
fmla.92 <- dynformula(as.formula(diff(govgdpt, 1) ~ 
        lag(govgdpt, 1) 
        + lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.92 <- plm(fmla.92, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
m.92sp <- plm(fmla.92, model="within", effect="twoways",  
          data=subset(data, polity2<=6 & gwf_party==1),
          na.action=na.omit,
          index = c("iso3c","year"))

# Table print
screenreg(list(m.91, m.92, m.91sp, m.92sp), 
label="tab:cooptation_publicsector",
caption="Effects education spending among trade competitors (interdependence) on public sector employment and total government spending",
custom.model.names = c('All Autocracies: Public employment', 'All Autocracies: Government Spending', 'Single-party Regimes: Public employment', 'Single-party Regimes: Government Spending'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# ========================================================================
# G Negative shocks of trade competition and increased domestic repression
# ========================================================================

# ============
# = TABLE 7 =
# ============

# ---- repression ----
# military spending as % of gdp
fmla.111 <- dynformula(as.formula(diff(ms_mil_xpnd_gd_zs, 1) ~ 
        lag(ms_mil_xpnd_gd_zs, 1)
        + lag(w.edugdpWBas, 1)        #+ diff(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.111 <- plm(fmla.111, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.111)
m.111nsp <- plm(fmla.111, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6& gwf_party==0),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.111nsp)

# Civil society organizations repression (v2csreprss)
fmla.112 <- dynformula(as.formula(diff(I(v2csreprss*-1), 1) ~ 
        lag(I(v2csreprss*-1), 1)
        + lag(w.edugdpWBas, 1)        
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        # + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.112 <- plm(fmla.112, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.112)
m.112nsp <- plm(fmla.112, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6& gwf_party==0),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.112nsp)

# Question : CSO control in entry/exit (v2cseeorgs)
fmla.113 <- dynformula(as.formula(diff(I(v2cseeorgs*-1), 1) ~ 
        lag(I(v2cseeorgs*-1), 1)
        + lag(w.edugdpWBas, 1)        
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        # + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.113 <- plm(fmla.113, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.113)
m.113nsp <- plm(fmla.113, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6& gwf_party==0),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.113nsp)

# Table print
# All : All regimes
# MPM : Military, Personal and Monarchies
screenreg(list(m.111, m.112, m.113,m.111nsp, m.112nsp, m.113nsp), 
label="tab:repression",
caption="Effects education spending among trade competitors (interdependence) on domestic military spending and civil society repression",
custom.model.names = c('All: Military spending/GDP', 'All: Civ. soc. repression', 'All: Civ. soc. control','MPM: Military spending/GDP', 'MPM: Civ. soc. repression', 'MPM: Civ. soc. control'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=TRUE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))


# =============================================
# H Autocratic regimes and developmental states
# =============================================

# ============
# = TABLE 8  =
# ============

# ---- ISI ----
fmla.121 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(isi_positive, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.121 <- plm(fmla.121, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.121)
fmla.122 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)
        + lag(isi_positive, 1)
        + lag(isi_positive, 1)*lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.122 <- plm(fmla.122, model="within", effect="twoways",  
  		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.122)

data$lac <- ifelse(data$region=="Americas", 1, 0)
data$asia <- ifelse(data$region=="Asia", 1, 0)
data$africa <- ifelse(data$region=="Africa", 1, 0)

fmla.123 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1) 
        + lag(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.123 <- plm(fmla.123, model="within",
  		  data=subset(data, polity2<=6&lac==1),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.123)
m.124 <- plm(fmla.123, model="within",
  		  data=subset(data, polity2<=6&asia==1),
		  na.action=na.omit,
		  index = c("iso3c","year"))
# summary(m.124)


# Table print
screenreg(list(m.121, m.122, m.123, m.124), 
label="tab:isi",
caption="Interdependence conditional on development strategies",
custom.model.names = c('All autocracies', 'All autocracies', 'Latin America', 'Asia'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# =========================================================
# I Interdependence conditional on trade openness and time
# =========================================================

# ============
# = TABLE 9  =
# ============

# ---- time.openness ----
data$d1990 <- ifelse(data$year<=1990, 0, 1)
fmla.51 <- dynformula(as.formula(diff(edugdpWBas, 1) ~
        lag(edugdpWBas, 1)
        + as.factor(d1990):diff(w.edugdpWBas,1)
        + as.factor(d1990):lag(w.edugdpWBas,1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.51 <- plm(fmla.51, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
fmla.53 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + I(lag(log(exportsgdp),1)*lag(w.edugdpWBas,1))
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.53 <- plm(fmla.53, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
fmla.54 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + I(lag(log(importsgdp),1)*lag(w.edugdpWBas,1))
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.54 <- plm(fmla.54, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))
fmla.55 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(kofrestrict, 1)         + diff(kofrestrict, 1)      
        + I(lag(log(kofrestrict),1)*lag(w.edugdpWBas,1))
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.55 <- plm(fmla.55, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))


# Table print
screenreg(list(m.51, m.53, m.54, m.55), 
label="tab:time.openness",
caption="Interdependence conditional on openness and time",
custom.model.names = c('1990', 'imports', 'exports', 'liberalization'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))


# ============
# = FIGURE 4 =
# ============

# By year
fmla.52 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + as.factor(year):diff(w.edugdpWBas,1)
        + as.factor(year):lag(w.edugdpWBas,1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.52 <- plm(fmla.52, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))

# By period
data$period <- cut(data$year,
                     breaks=c(-Inf, 1974, 1979, 1984, 1989, 1994, 1999, 2004, Inf),
                     labels=c("70-74","75-79","80-84","85-89","90-94","95-99","00-04","05-09"))
fmla.52b <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)
        + as.factor(period):diff(w.edugdpWBas,1)
        + as.factor(period):lag(w.edugdpWBas,1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.52b <- plm(fmla.52b, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))

# Extract the relevant results from the model 
ncoef <- length(coef(m.52))
years <- 2009-1971
x <- as.data.frame(cbind(1971:2009,
    coef(m.52)[(ncoef-years):ncoef],
    sqrt(diag(vcov(m.52)))[(ncoef-years):ncoef]))
names(x) <-c( "year", "beta", "std.beta")
#Plot
plot(x$year, x$beta, type="b", ylim=c(min(x$beta)-2*max(x$std.beta), max(x$beta)+2*max(x$std.beta)))
segments(x$year, c(x$beta-1.64*x$std.beta),
        x$year, c(x$beta+1.64*x$std.beta))
abline(0,0)

# Extract the relevant results from the model 
ncoef <- length(coef(m.52b))
periods <- length(table(data$period))
x <- as.data.frame(cbind(as.factor(unique(data$period)),
    coef(m.52b)[(ncoef-periods+1):ncoef],
    sqrt(diag(vcov(m.52b)))[(ncoef-periods+1):ncoef]))
names(x) <-c( "period", "beta", "std.beta")
#Plot
plot(x$period, x$beta, type="b", 
    ylim=c(min(x$beta)-2*max(x$std.beta), max(x$beta)+2*max(x$std.beta)),
    xaxt="n")
axis(1, at=unique(data$period),labels=unique(data$period), las=1)
segments(x$period, c(x$beta-1.64*x$std.beta),
        x$period, c(x$beta+1.64*x$std.beta))
abline(0,0)



# =========================================================
# J Education spending and outcome variables
# =========================================================

# ============
# = TABLE 10 =
# ============

#Take education spending in 1990 
ed.corr.dat <- subset(data, year==1990, select=edugdpWBas) 
#Take education outcomes in 1995 
out.corr.dat <- subset(data, year==1995, select=c(LDC, polity2, yr_sch15up, lpc15up, lsc15up, lhc15up, se_prm_enrr, se_sec_enrr, se_ter_enrr, ted_LPHourGK, ted_LPHourEKS, ted_LPPersonGK, ted_LPPersonEKS))
#column bind the data
dat.corr <- cbind(ed.corr.dat,out.corr.dat)
#Select autorcracies
dat.corr.aut <- dat.corr[dat.corr$polity2<=6,]
#Select democracies
dat.corr.dem <- dat.corr[dat.corr$polity2>=7 & dat.corr$LDC==1,]
#Take the pairwise correlations
c1 <- round(cor( dat.corr.aut, use="pairwise.complete.obs"),2)
c2 <- round(cor( dat.corr.dem, use="pairwise.complete.obs"),2)
#Extract relevant correlations
upperc1<-as.data.frame(c1)[1]
upperc2<-as.data.frame(c2)[1]
cor <- cbind(upperc1,upperc2)
cor <- cor[4:dim(cor)[1],]
names(cor)<-c("Educ. Spending in Autocracies","Educ. Spending in Democracies")
rownames(cor) <- c(
"Average Schooling" ,
"Population 15+ with primary education" ,
"Population 15+ with secondary education" ,
"Population 15+ with tertiary education" ,
"Enrollment rate primary education" ,
"Enrollment rate secondary education" ,
"Enrollment rate tertiary education" ,
"Labor productivity/hour (1990 USD)" ,
"Labor productivity/hour (2013 USD)" ,
"Labor productivity/worker (1990 USD)" ,
"Labor productivity/worker (2013 USD") 

print(cor)



# ============
# = TABLE 11 =
# ============


# ---- spending-outcomes ----
fmla.61 <- dynformula(as.formula(diff(se_prm_enrr, 1) ~ 
		+ lag(se_prm_enrr, 1)         + lag(diff(se_prm_enrr), 1) 
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.61 <- plm(fmla.61, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.62 <- dynformula(as.formula(diff(se_sec_enrr, 1) ~ 
		+ lag(se_sec_enrr, 1)         + lag(diff(se_sec_enrr), 1) 
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.62 <- plm(fmla.62, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.63 <- dynformula(as.formula(diff(se_ter_enrr, 1) ~ 
		+ lag(se_ter_enrr, 1)         + lag(diff(se_ter_enrr), 1) 
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.63 <- plm(fmla.63, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))

# Table print
screenreg(list(m.61, m.62, m.63), 
label="tab:spending-outcome1",
caption="Effects of education spending on enrollment rates in Autocracies",
custom.model.names = c('primary', 'secondary', 'tertiary'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))




# ============
# = TABLE 12 =
# ============


fmla.64 <- dynformula(as.formula(diff(yr_sch15up, 1) ~ 
		+ lag(yr_sch15up, 1)        + lag(diff(yr_sch15up), 1)
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.64 <- plm(fmla.64, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.65 <- dynformula(as.formula(diff(lpc15up, 1) ~ 
		+ lag(lpc15up, 1)           + lag(diff(lpc15up), 1)
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.65 <- plm(fmla.65, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.66 <- dynformula(as.formula(diff(lsc15up, 1) ~ 
		+ lag(lsc15up, 1)           + lag(diff(lsc15up), 1)
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.66 <- plm(fmla.66, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.67 <- dynformula(as.formula(diff(lhc15up, 1) ~ 
		+ lag(lhc15up, 1)           + lag(diff(lhc15up), 1)
        + lag(edugdpWBas, 1)          + diff(edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
  		))
m.67 <- plm(fmla.67, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))


# Table print
screenreg(list(m.64, m.65, m.66, m.67), 
label="tab:spending-outcome2",
caption="Effects of education spending on educational attainment in autocracies",
custom.model.names = c('avg. years schooling', 'pct primary', 'pct secondary', 'pct tertiary'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))

# ===============================================================
# K Foreign educational outcomes and domestic education spending
# ===============================================================

# ============
# = TABLE 13 =
# ============

# ---- spat.lag.outcomes.spending ----
fmla.81 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
		lag(edugdpWBas, 1)            + lag(diff(edugdpWBas, 1), 1)
		+ lag(w.yr_sch15up, 1)      + diff(w.yr_sch15up, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.81 <- plm(fmla.81, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))
fmla.82 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)            + lag(diff(edugdpWBas, 1), 1)
        + lag(w.ted_LPHourGK, 1)      + diff(w.ted_LPHourGK, 1)
        + lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
        ))
m.82 <- plm(fmla.82, effect="twoways",
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c("iso3c","year"))


# Table print
screenreg(list(m.81, m.82), 
label="tab:spat.lag.outcomes",
caption="Spatial lags of schooling and labor productivity on domestic spending",
custom.model.names = c('avg. years schooling', 'labor productivity'),
single.row=TRUE,
include.rsquared = FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# ===============================================================
# L Robust covariance matrix and clustered standard errors
# ===============================================================

# ============
# = TABLE 14 =
# ============



# ---- clustered.standarderrors ----
fmla.131 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
		lag(edugdpWBas, 1)            #+ lag(diff(edugdpWBas, 1), 1)
		+ lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
		))
m.131 <- plm(fmla.131, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))

fmla.132 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
		lag(edugdpWBas, 1)            #+ lag(diff(edugdpWBas, 1), 1)
		+ lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
		+ lag(wreg.edugdpWBas, 1)     + diff(wreg.edugdpWBas, 1)
        + lag(log(importsgdp), 1)     + diff(log(importsgdp), 1)      
        + lag(log(exportsgdp), 1)     + diff(log(exportsgdp), 1)      
        + lag(polity2, 1)             + diff(polity2, 1)
        + lag(pop014pct, 1)           + diff(pop014pct, 1)
        + lag(urbpop, 1)              + diff(urbpop, 1)
        + lag(log(pop_total), 1)      + diff(log(pop_total), 1)
        + lag(gdppcconstus,1)         + diff(gdppcconstus,1)
        + lag(govconsgdp, 1)          + diff(govconsgdp, 1)
        + lag(outputgap_pc002, 1)     + diff(outputgap_pc002, 1) 
		))
m.132 <- plm(fmla.132, effect="twoways",
		  data=subset(data, polity2<=6),
		  na.action=na.omit,
		  index = c("iso3c","year"))

# Table print
screenreg(list(m.131, m.132, m.131, m.132), 
label="tab:cluster",
caption="Interdependence with PCSE clustered by country",
custom.model.names = c('s.e. clustered by group', 's.e. clustered by group', 's.e. clustered by time', 's.e. clustered by time'),
float.pos="h",
scalebox = .8,
single.row=TRUE,
include.rsquared = FALSE,
booktabs = TRUE,
dcolumn = TRUE,
use.packages=FALSE,
stars = c(0.01, 0.05, 0.1),
sideways=FALSE,
override.se=list(coeftest(m.131, vcov.=function(x) vcovBK(x, type="HC1", cluster="group"))[,2],
                 coeftest(m.132, vcov.=function(x) vcovBK(x, type="HC1", cluster="group"))[,2],
                 coeftest(m.131, vcov.=function(x) vcovBK(x, type="HC1", cluster="time"))[,2],
                 coeftest(m.132, vcov.=function(x) vcovBK(x, type="HC1", cluster="time"))[,2]),
override.pval=list(coeftest(m.131, vcov.=function(x) vcovBK(x, type="HC1", cluster="group"))[,4],
				   coeftest(m.132, vcov.=function(x) vcovBK(x, type="HC1", cluster="group"))[,4],
				   coeftest(m.131, vcov.=function(x) vcovBK(x, type="HC1", cluster="time"))[,4],
				   coeftest(m.132, vcov.=function(x) vcovBK(x, type="HC1", cluster="time"))[,4]),
custom.note= paste("%stars.","Country and year fixed effects are included in the models."))



# ===============================================================
# M Panel unit root tests
# ===============================================================


# ============
# = TABLE 15 =
# ============

# general model of interdependence
fmla.11 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)            #+ lag(diff(edugdpWBas, 1), 1)
        + lag(w.edugdpWBas, 1)        + diff(w.edugdpWBas, 1)
        ))
m.11 <- plm(fmla.11, effect='twoways',
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c('iso3c','year'))
# get the country sample
countrylist <- as.character(names(fixef(m.11))) 
# get the complete education time series
series <- as.data.frame(split(data$edugdpWBas, data$iso3c)) # extract series by country
series <- series[countrylist] # only consider the countries in 'model 1'
complete.series <- series[countrylist[colSums(is.na(series))==0]] # only consider complete series

# Test the unit root hypotheses for education spending 
# Levin et al. (2002) panel unit root test based on a pooled statistic.
# Ha: “all of the series are I(0) ” 
levinlin <- purtest(complete.series, pmax=5, exo='intercept', test='levinlin', lags='AIC', dfcor = TRUE) 
# print(levinlin)
z1 <- levinlin[[1]][[1]][[1]]
pval1 <-  levinlin[[1]][[6]][[1]]

#  Im et al. (2003) developed a mean-group test 
# Ha: “at least one of the series is I(0)”
ips <- purtest(complete.series, pmax=5, exo='intercept', test='ips', lags='AIC', dfcor = TRUE) 
# print(ips)
z2 <- ips[[1]][[1]][[1]]
pval2 <-  ips[[1]][[6]][[1]]


# Test the unit root hypotheses for unbounded time seeries of education spending  (in constant USD)
data$edugdpWBas.usd <- log((data$edugdpWBas/100)*data$gdpconstus)
series <- as.data.frame(split(data$edugdpWBas.usd, data$iso3c)) # extract series by country
series <- series[countrylist] # only consider the countries in 'model 1'
complete.series <- series[countrylist[colSums(is.na(series))==0]]
# Test unit root hypotheses with panel data
levinlin <- purtest(complete.series, pmax=5, exo='intercept', test='levinlin', lags='AIC', dfcor = TRUE) 
# print(levinlin)
z3 <- levinlin[[1]][[1]][[1]]
pval3 <-  levinlin[[1]][[6]][[1]]
ips <- purtest(complete.series, pmax=5, exo='trend', test='ips', lags='AIC', dfcor = TRUE) 
# print(ips)
z4 <- ips[[1]][[1]][[1]]
pval4 <-  ips[[1]][[6]][[1]]

# Test the unit root hypotheses for the spatial lag of education spending 
series <- as.data.frame(split(data$w.edugdpWBas, data$iso3c)) # extract series by country
series <- series[countrylist] # only consider the countries in 'model 1'
complete.series <- series[countrylist[colSums(is.na(series))==0]]
# Test unit root hypotheses with panel data
levinlin <- purtest(complete.series, pmax=5, exo='intercept', test='levinlin', lags='AIC', dfcor = TRUE)  
# print(levinlin)
z5 <- levinlin[[1]][[1]][[1]]
pval5 <-  levinlin[[1]][[6]][[1]]

ips <- purtest(complete.series, pmax=5, exo='trend', test='ips', lags='AIC', dfcor = TRUE) 
# print(ips)
z6 <- ips[[1]][[1]][[1]]
pval6 <-  ips[[1]][[6]][[1]]

# Table print
tab15 <- round(cbind(c(z1, z2, z3, z4, z5, z6),c(pval1,pval2,pval3,pval4,pval5,pval6)), 5)  
colnames(tab15) <- c("z", "p-value")
test <- rep(c("Levin-Lin-Chu", "Im-Pesaran-Shin"), 3)
variable <- c(rep("Education spending as % of GDP", 2),
        rep("Education spending in constant U.S.D", 2),
        rep("Spatial lag of Education spending", 2) )
tab15 <- cbind(variable, test, as.data.frame(tab15) )
print(tab15)



# ===============================================================
# N Selection bias due to democratization
# ===============================================================


# ---- DropOuts ----
fmla.11 <- dynformula(as.formula(diff(edugdpWBas, 1) ~ 
        lag(edugdpWBas, 1)            #+ lag(diff(edugdpWBas, 1), 1)
        + lag(w.edugdpWBas, 1)        #+ w.d.edugdpWBas
        ))
m.11 <- plm(fmla.11, effect='twoways',
          data=subset(data, polity2<=6),
          na.action=na.omit,
          index = c('iso3c','year'))
# summary(m.11)

# get the country sample and identify political regimes
countrylist <- as.character(names(fixef(m.11))) 
data.dropouts <- subset(data, iso3c %in% countrylist)

# ============
# = FIGURE 5 =
# ============

ggplot(data.dropouts, aes(year, country)) +
 geom_tile(aes(fill = democracy) ,show.legend = FALSE)+
 scale_x_continuous(expand = c(0,0)) +
 scale_fill_gradient(low = "red", high = "blue") +
    xlab("Year") +
    ylab("Country")+
    theme(text = element_text(size=10))


# ============
# = FIGURE 6 =
# ============

# install.packages('dplyr')
library(plyr)
data.dropouts <- ddply(
    data.dropouts,
    .(iso3c), 
    mutate, 
    year.dropout= max(ifelse(d.democracy==1, year, 0), na.rm=TRUE),
    time.drop = year - year.dropout,
    edu.since.dropout = edugdpWBas - max(ifelse(time.drop==0, edugdpWBas, 0), na.rm=TRUE)
    )
detach("package:plyr", unload=TRUE) # better not to work with the plm package and plyr at the same time.

ggplot(data.dropouts[data.dropouts$time.drop>=0 & data.dropouts$time.drop<=5 & data.dropouts$democracy==1,], 
    aes(x=time.drop, y=edu.since.dropout)) +
    geom_line(aes(group=iso3c), colour="grey") +
    geom_point(aes(group=iso3c), colour="black") +
    # facet_wrap(~ iso3c) +
    ylim(-3,4) +
    # scale_colour_grey() +
    stat_smooth() +
    xlab("Years after democratization") +
    ylab("Evolution of education spending") 
